import { useEffect } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/context/AuthContext';
import AdminLayout from '@/components/admin/AdminLayout';
import AdminDashboard from '@/components/admin/AdminDashboard';
import AnimeList from '@/components/admin/AnimeList';
import AddAnimeForm from '@/components/admin/AddAnimeForm';
import EpisodeManagement from '@/components/admin/EpisodeManagement';
import ImportFromTMDB from '@/components/admin/ImportFromTMDB';
import EpisodeEmbedManager from '@/components/admin/EpisodeEmbedManager';
import { Card, CardContent } from '@/components/ui/card';
import { Cog, UserCog } from 'lucide-react';

interface AdminProps {
  page?: string;
}

const Admin = ({ page = 'dashboard' }: AdminProps) => {
  const { user, loading } = useAuth();
  const [_, navigate] = useLocation();

  useEffect(() => {
    if (!loading && (!user || user.role !== 'admin')) {
      navigate('/login');
    }
  }, [user, loading, navigate]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  // Title and content based on current page
  let title = 'Dashboard';
  let content;

  switch (page) {
    case 'dashboard':
      title = 'Dashboard';
      content = <AdminDashboard />;
      break;
    case 'anime-list':
      title = 'Anime List';
      content = <AnimeList />;
      break;
    case 'add-anime':
      title = 'Add Anime';
      content = <AddAnimeForm />;
      break;
    case 'episodes':
      title = 'Episode Management';
      content = <EpisodeManagement />;
      break;
    case 'add-episode':
      title = 'Add Episode';
      content = <EpisodeEmbedManager />;
      break;
    case 'import-tmdb':
      title = 'Import from TMDB';
      content = <ImportFromTMDB />;
      break;
    case 'users':
      title = 'User Management';
      content = (
        <Card className="bg-surface shadow-lg border-none">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <UserCog className="h-16 w-16 text-text-secondary mb-4" />
            <h3 className="text-xl font-medium">User Management</h3>
            <p className="text-text-secondary mt-2 text-center max-w-md">
              This feature is coming soon. You'll be able to manage users, roles, and permissions.
            </p>
          </CardContent>
        </Card>
      );
      break;
    case 'settings':
      title = 'Settings';
      content = (
        <Card className="bg-surface shadow-lg border-none">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <Cog className="h-16 w-16 text-text-secondary mb-4" />
            <h3 className="text-xl font-medium">Settings</h3>
            <p className="text-text-secondary mt-2 text-center max-w-md">
              System settings will be available here soon. You'll be able to configure site-wide preferences.
            </p>
          </CardContent>
        </Card>
      );
      break;
    default:
      content = <AdminDashboard />;
  }

  return (
    <AdminLayout title={title} currentPage={page}>
      {content}
    </AdminLayout>
  );
};

export default Admin;
