import { useState, useEffect } from 'react';
import { useParams, Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import VideoPlayer from '@/components/player/VideoPlayer';
import CommentSection from '@/components/player/CommentSection';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertCircle, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Episode, Anime } from '@shared/schema';

const WatchEpisode = () => {
  const { animeId, episodeId } = useParams();
  const parsedAnimeId = parseInt(animeId);
  const parsedEpisodeId = parseInt(episodeId);

  const { 
    data: episode, 
    isLoading: isEpisodeLoading,
    isError: isEpisodeError 
  } = useQuery({
    queryKey: [`/api/episodes/${parsedEpisodeId}`],
    enabled: !!parsedEpisodeId && !isNaN(parsedEpisodeId),
  });

  const { 
    data: anime, 
    isLoading: isAnimeLoading
  } = useQuery({
    queryKey: [`/api/animes/${parsedAnimeId}`],
    enabled: !!parsedAnimeId && !isNaN(parsedAnimeId),
  });

  const { 
    data: episodesList, 
    isLoading: isEpisodesListLoading
  } = useQuery({
    queryKey: [`/api/animes/${parsedAnimeId}/episodes`],
    enabled: !!parsedAnimeId && !isNaN(parsedAnimeId),
  });

  const {
    data: comments,
    isLoading: isCommentsLoading,
    refetch: refetchComments
  } = useQuery({
    queryKey: [`/api/episodes/${parsedEpisodeId}/comments`],
    enabled: !!parsedEpisodeId && !isNaN(parsedEpisodeId),
  });

  // Get the next episodes in the series
  const getNextEpisodes = () => {
    if (!episodesList || !episode) return [];
    
    const currentEpisode = episode;
    return episodesList
      .filter((ep: Episode) => ep.season_number === currentEpisode.season_number)
      .filter((ep: Episode) => ep.episode_number > currentEpisode.episode_number)
      .sort((a: Episode, b: Episode) => a.episode_number - b.episode_number)
      .slice(0, 6);
  };

  // Get next episode for auto-play
  const getNextEpisode = () => {
    const nextEpisodes = getNextEpisodes();
    return nextEpisodes.length > 0 ? nextEpisodes[0] : null;
  };

  const handleVideoEnd = () => {
    const nextEpisode = getNextEpisode();
    if (nextEpisode) {
      window.location.href = `/watch/${animeId}/${nextEpisode.id}`;
    }
  };

  if (isEpisodeError) {
    return (
      <div className="container mx-auto px-4 pt-24 pb-10">
        <Alert variant="destructive" className="mb-6">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>
            Failed to load episode. Please try again later.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 pt-24 pb-10">
      <Card className="bg-surface rounded-xl overflow-hidden shadow-lg mb-8">
        <CardContent className="p-0">
          <div className="flex flex-col md:flex-row">
            <div className="w-full md:w-3/4">
              {/* Video Player */}
              <VideoPlayer 
                episode={episode || null} 
                isLoading={isEpisodeLoading}
                onVideoEnd={handleVideoEnd}
              />
              
              {/* Episode Info */}
              <div className="p-4 border-b border-secondary">
                {isEpisodeLoading || isAnimeLoading ? (
                  <div>
                    <Skeleton className="h-8 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-1/2 mb-4" />
                    <Skeleton className="h-4 w-full mb-1" />
                    <Skeleton className="h-4 w-full mb-1" />
                    <Skeleton className="h-4 w-3/4" />
                  </div>
                ) : episode && anime ? (
                  <div>
                    <div className="flex justify-between items-start">
                      <div>
                        <h1 className="text-xl font-bold font-inter">
                          {anime.title} - Episode {episode.episode_number}: {episode.title}
                        </h1>
                        <div className="flex items-center text-text-secondary text-sm mt-1">
                          <span>{new Date(episode.release_date).toLocaleDateString()}</span>
                          <span className="mx-2">•</span>
                          <span>{episode.duration}</span>
                          <span className="mx-2">•</span>
                          <span>Season {episode.season_number}</span>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button 
                          variant="secondary"
                          className="bg-secondary hover:bg-opacity-80 text-text-primary"
                          size="icon"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M7 10v12"/>
                            <path d="M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2h0a3.13 3.13 0 0 1 3 3.88Z"/>
                          </svg>
                        </Button>
                        <Button 
                          variant="secondary"
                          className="bg-secondary hover:bg-opacity-80 text-text-primary"
                          size="icon"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/>
                            <polyline points="16 6 12 2 8 6"/>
                            <line x1="12" y1="2" x2="12" y2="15"/>
                          </svg>
                        </Button>
                        <Button 
                          variant="secondary"
                          className="bg-secondary hover:bg-opacity-80 text-text-primary"
                          size="icon"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <circle cx="18" cy="5" r="3"/>
                            <circle cx="6" cy="12" r="3"/>
                            <circle cx="18" cy="19" r="3"/>
                            <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/>
                            <line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
                          </svg>
                        </Button>
                      </div>
                    </div>
                    
                    <p className="text-text-secondary mt-4">
                      {episode.description || 'No description available for this episode.'}
                    </p>
                  </div>
                ) : (
                  <div className="text-center py-4">
                    <p>Episode information not available</p>
                  </div>
                )}
              </div>
              
              {/* Comments Section */}
              <CommentSection 
                episodeId={parsedEpisodeId} 
                comments={comments || []} 
                isLoading={isCommentsLoading} 
                refetch={refetchComments}
              />
            </div>
            
            {/* Up Next Section */}
            <div className="w-full md:w-1/4 border-l border-secondary hidden md:block">
              <div className="p-4">
                <h2 className="text-lg font-bold font-inter mb-4">Up Next</h2>
                
                <div className="space-y-4 overflow-y-auto max-h-[600px] scrollbar-hide">
                  {isEpisodesListLoading ? (
                    Array(4).fill(null).map((_, index) => (
                      <div key={index} className="flex p-2">
                        <Skeleton className="w-24 h-16 mr-3" />
                        <div>
                          <Skeleton className="h-4 w-16 mb-1" />
                          <Skeleton className="h-5 w-28 mb-1" />
                          <Skeleton className="h-3 w-12" />
                        </div>
                      </div>
                    ))
                  ) : getNextEpisodes().length > 0 ? (
                    getNextEpisodes().map((nextEp: Episode) => (
                      <Link 
                        key={nextEp.id} 
                        href={`/watch/${animeId}/${nextEp.id}`}
                      >
                        <div className="flex hover:bg-secondary/50 rounded-lg p-2 cursor-pointer">
                          <div className="w-24 h-16 relative shrink-0 mr-3">
                            <img 
                              src={nextEp.thumbnail} 
                              alt={`Episode ${nextEp.episode_number}`} 
                              className="w-full h-full object-cover rounded-md"
                              loading="lazy"
                            />
                            <div className="absolute inset-0 flex items-center justify-center">
                              <div className="bg-black/70 rounded-full w-6 h-6 flex items-center justify-center">
                                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="white" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                  <polygon points="5 3 19 12 5 21 5 3"/>
                                </svg>
                              </div>
                            </div>
                          </div>
                          <div>
                            <h3 className="font-medium text-sm">Episode {nextEp.episode_number}</h3>
                            <h4 className="text-text-secondary text-xs line-clamp-1">{nextEp.title}</h4>
                            <span className="text-text-secondary text-xs">{nextEp.duration}</span>
                          </div>
                        </div>
                      </Link>
                    ))
                  ) : (
                    <div className="text-center py-4 text-text-secondary">
                      <p>No more episodes available</p>
                      <Link href={`/anime/${animeId}`}>
                        <Button 
                          variant="link" 
                          className="text-primary hover:underline flex items-center text-sm mt-2"
                        >
                          Back to anime page <ChevronRight className="ml-1 h-4 w-4" />
                        </Button>
                      </Link>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default WatchEpisode;
