import { useQuery } from '@tanstack/react-query';
import { useParams } from 'wouter';
import AnimeInfo from '@/components/anime/AnimeInfo';
import EpisodeList from '@/components/anime/EpisodeList';
import ReviewSection from '@/components/anime/ReviewSection';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertCircle } from 'lucide-react';

const AnimeDetails = () => {
  const { id } = useParams();
  const animeId = parseInt(id);

  const { 
    data: anime, 
    isLoading: isAnimeLoading,
    isError: isAnimeError,
    error: animeError
  } = useQuery({
    queryKey: [`/api/animes/${animeId}`],
    enabled: !!animeId && !isNaN(animeId),
  });

  const { 
    data: episodes, 
    isLoading: isEpisodesLoading,
    isError: isEpisodesError,
    error: episodesError
  } = useQuery({
    queryKey: [`/api/animes/${animeId}/episodes`],
    enabled: !!animeId && !isNaN(animeId),
  });

  const { 
    data: reviews, 
    isLoading: isReviewsLoading,
    isError: isReviewsError,
    error: reviewsError,
    refetch: refetchReviews
  } = useQuery({
    queryKey: [`/api/animes/${animeId}/reviews`],
    enabled: !!animeId && !isNaN(animeId),
  });

  if (isAnimeError) {
    return (
      <div className="container mx-auto px-4 pt-24 pb-10">
        <Alert variant="destructive" className="mb-6">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>
            Failed to load anime details. Please try again later.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 pt-24 pb-10">
      {/* Anime Info Section */}
      <AnimeInfo anime={anime || null} isLoading={isAnimeLoading} />
      
      {/* Episodes Section */}
      <EpisodeList 
        animeId={animeId} 
        episodes={episodes || []} 
        isLoading={isEpisodesLoading} 
      />
      
      {/* Reviews Section */}
      <ReviewSection 
        animeId={animeId} 
        reviews={reviews || []} 
        isLoading={isReviewsLoading}
        refetch={refetchReviews}
      />
    </div>
  );
};

export default AnimeDetails;
