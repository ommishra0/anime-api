import { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import AnimeSection from '@/components/home/AnimeSection';
import { Skeleton } from '@/components/ui/skeleton';
import { Anime } from '@shared/schema';
import { Card, CardContent } from '@/components/ui/card';
import { SlidersHorizontal, ListFilter } from 'lucide-react';

const Home = () => {
  const { data: allAnimes, isLoading: isAllAnimesLoading } = useQuery({
    queryKey: ['/api/animes'],
  });

  const { data: trendingAnime, isLoading: isTrendingLoading } = useQuery({
    queryKey: ['/api/animes/trending'],
  });

  const { data: recentlyAddedAnime, isLoading: isRecentLoading } = useQuery({
    queryKey: ['/api/animes/recent'],
  });

  const { data: topRatedAnime, isLoading: isTopRatedLoading } = useQuery({
    queryKey: ['/api/animes/top-rated'],
  });

  return (
    <div className="container mx-auto px-4 pt-20 pb-10">
      {/* Header with counts */}
      <div className="flex flex-col md:flex-row justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Anime Collection</h1>
          <p className="text-text-secondary">
            Explore {allAnimes ? allAnimes.length : '...'} titles in our growing library
          </p>
        </div>
        <div className="flex space-x-2 mt-4 md:mt-0">
          <Card className="bg-surface border-none shadow">
            <CardContent className="flex items-center p-2">
              <SlidersHorizontal className="h-4 w-4 mr-2 text-primary" />
              <span className="text-sm">Sort</span>
            </CardContent>
          </Card>
          <Card className="bg-surface border-none shadow">
            <CardContent className="flex items-center p-2">
              <ListFilter className="h-4 w-4 mr-2 text-primary" />
              <span className="text-sm">Filter</span>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* All Anime Grid */}
      <Card className="bg-surface border-none shadow-lg mb-8">
        <CardContent className="p-6">
          <h2 className="text-xl font-semibold mb-4">All Anime</h2>
          {isAllAnimesLoading ? (
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {[...Array(10)].map((_, index) => (
                <div key={index} className="flex flex-col">
                  <Skeleton className="w-full aspect-[2/3] rounded-md mb-2" />
                  <Skeleton className="h-4 w-3/4 mb-1" />
                  <Skeleton className="h-3 w-1/2" />
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {(allAnimes || []).map((anime: Anime) => (
                <a 
                  key={anime.id} 
                  href={`/anime/${anime.id}`}
                  className="group transition-transform duration-200 hover:scale-105"
                >
                  <div className="relative rounded-md overflow-hidden mb-2 aspect-[2/3]">
                    <img 
                      src={anime.cover_image} 
                      alt={anime.title} 
                      className="w-full h-full object-cover" 
                    />
                    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-2">
                      <div className="text-xs text-white font-medium truncate">
                        {anime.episodes_count} Episodes
                      </div>
                      <div className="text-xs text-amber-400">
                        ★ {anime.rating || 'N/A'}
                      </div>
                    </div>
                  </div>
                  <h3 className="font-medium text-white group-hover:text-primary truncate">
                    {anime.title}
                  </h3>
                  <p className="text-xs text-text-secondary truncate">
                    {anime.alternative_title || anime.type}
                  </p>
                </a>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Trending Anime Section */}
      <AnimeSection 
        title="Trending Now" 
        animes={trendingAnime || []} 
        viewAllLink="/trending" 
        isLoading={isTrendingLoading} 
      />

      {/* Recently Added Section */}
      <AnimeSection 
        title="Recently Added" 
        animes={recentlyAddedAnime || []} 
        viewAllLink="/recent" 
        isLoading={isRecentLoading} 
      />

      {/* Top Rated Section */}
      <AnimeSection 
        title="Top Rated" 
        animes={topRatedAnime || []} 
        viewAllLink="/top-rated" 
        isLoading={isTopRatedLoading} 
      />
    </div>
  );
};

export default Home;
