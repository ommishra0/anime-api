import { Switch, Route, Link, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import AnimeDetails from "@/pages/AnimeDetails";
import WatchEpisode from "@/pages/WatchEpisode";
import Login from "@/pages/Login";
import Admin from "@/pages/Admin";
import Footer from "@/components/layout/Footer";
import { AuthProvider, useAuth } from "./context/AuthContext";
import { Button } from "@/components/ui/button";
import { Search, Menu, X } from 'lucide-react';
import { Input } from "@/components/ui/input";
import { useState } from "react";

// Simple navbar with auth
function SimpleNavbar() {
  const [location, navigate] = useLocation();
  const { user, logout } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    console.log(`Searching for: ${searchQuery}`);
  };

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  return (
    <nav className="fixed top-0 w-full bg-surface shadow-md z-50">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <Link href="/" className="flex items-center">
              <span className="text-primary text-2xl font-bold">Anime<span className="text-accent">Stream</span></span>
            </Link>
            <div className="hidden md:flex space-x-6 ml-10">
              <Link href="/" className={`hover:text-primary transition-colors font-medium ${location === '/' ? 'text-primary' : 'text-text-secondary'}`}>
                Home
              </Link>
              <Link href="/browse" className={`hover:text-primary transition-colors font-medium ${location === '/browse' ? 'text-primary' : 'text-text-secondary'}`}>
                Browse
              </Link>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            {user ? (
              <div className="flex items-center space-x-2">
                {user.role === 'admin' && (
                  <Button 
                    variant="ghost" 
                    onClick={() => navigate('/admin')}
                    className="text-text-secondary hover:text-primary"
                  >
                    Admin
                  </Button>
                )}
                <Button 
                  variant="ghost" 
                  onClick={handleLogout}
                  className="text-text-secondary hover:text-primary"
                >
                  Logout
                </Button>
              </div>
            ) : (
              <Button 
                onClick={() => navigate('/login')}
                className="text-white bg-primary hover:bg-opacity-80 transition-colors"
              >
                Login
              </Button>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}

// Content component that uses the auth context
function AppContent() {
  const { user } = useAuth();
  
  return (
    <div className="flex flex-col min-h-screen bg-background text-text-primary">
      <SimpleNavbar />
      <main className="flex-grow pt-16">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/anime/:id" component={AnimeDetails} />
          <Route path="/watch/:animeId/:episodeId" component={WatchEpisode} />
          <Route path="/login">
            <Login />
          </Route>
          <Route path="/admin/:page?">
            {params => (
              user && user.role === 'admin' ? 
                <Admin page={params.page || "dashboard"} /> : 
                <Login redirectTo="/admin" />
            )}
          </Route>
          <Route component={NotFound} />
        </Switch>
      </main>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <AppContent />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
