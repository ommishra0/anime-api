import { useState } from 'react';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { ThumbsUp, ThumbsDown, Reply } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { Comment, User } from '@shared/schema';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

interface CommentSectionProps {
  episodeId: number;
  comments: (Comment & { user: User; replies?: (Comment & { user: User })[] })[];
  isLoading: boolean;
  refetch: () => void;
}

const CommentSection = ({ episodeId, comments, isLoading, refetch }: CommentSectionProps) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [commentText, setCommentText] = useState('');
  const [replyText, setReplyText] = useState<Record<number, string>>({});
  const [showReplyForm, setShowReplyForm] = useState<Record<number, boolean>>({});
  const [visibleCount, setVisibleCount] = useState(5);

  const handleSubmitComment = async () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please log in to comment",
        variant: "destructive",
      });
      return;
    }

    if (!commentText.trim()) {
      toast({
        title: "Empty comment",
        description: "Please write something before submitting",
        variant: "destructive",
      });
      return;
    }

    try {
      await apiRequest('POST', '/api/comments', {
        user_id: user.id,
        episode_id: episodeId,
        content: commentText,
      });
      
      toast({
        title: "Comment submitted",
        description: "Your comment has been posted",
      });
      
      setCommentText('');
      refetch();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to submit comment. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleSubmitReply = async (parentId: number) => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please log in to reply",
        variant: "destructive",
      });
      return;
    }

    const reply = replyText[parentId];
    if (!reply?.trim()) {
      toast({
        title: "Empty reply",
        description: "Please write something before submitting",
        variant: "destructive",
      });
      return;
    }

    try {
      await apiRequest('POST', '/api/comments', {
        user_id: user.id,
        episode_id: episodeId,
        content: reply,
        parent_id: parentId,
      });
      
      toast({
        title: "Reply submitted",
        description: "Your reply has been posted",
      });
      
      setReplyText(prev => ({ ...prev, [parentId]: '' }));
      setShowReplyForm(prev => ({ ...prev, [parentId]: false }));
      refetch();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to submit reply. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleVote = async (commentId: number, isLike: boolean) => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please log in to vote",
        variant: "destructive",
      });
      return;
    }

    try {
      await apiRequest('POST', `/api/comments/${commentId}/vote`, {
        is_like: isLike,
      });
      refetch();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to vote. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleLoadMore = () => {
    setVisibleCount(prev => prev + 5);
  };

  const toggleReplyForm = (commentId: number) => {
    setShowReplyForm(prev => ({
      ...prev,
      [commentId]: !prev[commentId]
    }));
  };

  if (isLoading) {
    return (
      <div className="p-4">
        <h2 className="text-lg font-bold font-inter mb-4">Comments</h2>
        
        <div className="flex mb-6">
          <Skeleton className="w-10 h-10 rounded-full mr-3" />
          <div className="w-full">
            <Skeleton className="w-full h-20 rounded-lg" />
            <div className="flex justify-end mt-2">
              <Skeleton className="h-9 w-24" />
            </div>
          </div>
        </div>
        
        <div className="space-y-6">
          {[1, 2, 3].map(index => (
            <div className="flex" key={index}>
              <Skeleton className="w-10 h-10 rounded-full mr-3" />
              <div className="w-full">
                <div className="flex items-center">
                  <Skeleton className="h-5 w-32 mr-2" />
                  <Skeleton className="h-4 w-20" />
                </div>
                <Skeleton className="h-4 w-full mt-1 mb-1" />
                <Skeleton className="h-4 w-full mb-2" />
                <div className="flex items-center">
                  <Skeleton className="h-5 w-16 mr-4" />
                  <Skeleton className="h-5 w-16 mr-4" />
                  <Skeleton className="h-5 w-16" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4">
      <h2 className="text-lg font-bold font-inter mb-4">Comments ({comments.length})</h2>
      
      <div className="flex mb-6">
        <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center mr-3 shrink-0">
          <span className="text-primary font-bold">
            {user ? user.username.substring(0, 2).toUpperCase() : 'G'}
          </span>
        </div>
        <div className="w-full">
          <Textarea 
            placeholder="Add a comment..." 
            className="w-full bg-secondary rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-primary text-text-primary resize-none"
            rows={2}
            value={commentText}
            onChange={(e) => setCommentText(e.target.value)}
          />
          <div className="flex justify-end mt-2">
            <Button 
              className="bg-primary hover:bg-opacity-80 text-white"
              onClick={handleSubmitComment}
            >
              Comment
            </Button>
          </div>
        </div>
      </div>
      
      {comments.length === 0 ? (
        <div className="text-center py-8 text-text-secondary">
          No comments yet. Be the first to comment!
        </div>
      ) : (
        <div className="space-y-6">
          {comments.slice(0, visibleCount).map((comment) => (
            <div key={comment.id}>
              <div className="flex">
                <Avatar className="w-10 h-10 mr-3 shrink-0">
                  <AvatarFallback className="bg-accent/20 text-accent">
                    {comment.user.username.substring(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div className="w-full">
                  <div className="flex items-center">
                    <h4 className="font-medium">{comment.user.username}</h4>
                    <span className="text-text-secondary text-sm ml-2">
                      {new Date(comment.created_at).toLocaleDateString(undefined, { 
                        year: 'numeric', 
                        month: 'short', 
                        day: 'numeric' 
                      })}
                    </span>
                  </div>
                  <p className="text-text-secondary mt-1">
                    {comment.content}
                  </p>
                  <div className="flex items-center mt-2 text-text-secondary text-sm">
                    <button 
                      className="flex items-center mr-4 hover:text-text-primary"
                      onClick={() => handleVote(comment.id, true)}
                    >
                      <ThumbsUp className="mr-1 h-4 w-4" /> {comment.likes || 0}
                    </button>
                    <button 
                      className="flex items-center mr-4 hover:text-text-primary"
                      onClick={() => handleVote(comment.id, false)}
                    >
                      <ThumbsDown className="mr-1 h-4 w-4" /> {comment.dislikes || 0}
                    </button>
                    <button 
                      className="hover:text-text-primary"
                      onClick={() => toggleReplyForm(comment.id)}
                    >
                      Reply
                    </button>
                  </div>
                  
                  {/* Reply Form */}
                  {showReplyForm[comment.id] && (
                    <div className="mt-3 ml-6">
                      <div className="flex">
                        <Avatar className="w-8 h-8 mr-2 shrink-0">
                          <AvatarFallback className="bg-primary/20 text-primary text-xs">
                            {user ? user.username.substring(0, 2).toUpperCase() : 'G'}
                          </AvatarFallback>
                        </Avatar>
                        <div className="w-full">
                          <Textarea 
                            placeholder="Add a reply..." 
                            className="w-full bg-secondary rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-primary text-text-primary resize-none text-sm"
                            rows={2}
                            value={replyText[comment.id] || ''}
                            onChange={(e) => setReplyText(prev => ({ ...prev, [comment.id]: e.target.value }))}
                          />
                          <div className="flex justify-end mt-2">
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="mr-2"
                              onClick={() => toggleReplyForm(comment.id)}
                            >
                              Cancel
                            </Button>
                            <Button 
                              size="sm" 
                              className="bg-primary hover:bg-opacity-80 text-white"
                              onClick={() => handleSubmitReply(comment.id)}
                            >
                              Reply
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {/* Replies */}
                  {comment.replies && comment.replies.length > 0 && (
                    <div className="mt-4 space-y-4 ml-6">
                      {comment.replies.map(reply => (
                        <div className="flex" key={reply.id}>
                          <Avatar className="w-8 h-8 mr-2 shrink-0">
                            <AvatarFallback className="bg-primary/20 text-primary text-xs">
                              {reply.user.username.substring(0, 2).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="flex items-center">
                              <h4 className="font-medium">{reply.user.username}</h4>
                              <span className="text-text-secondary text-xs ml-2">
                                {new Date(reply.created_at).toLocaleDateString(undefined, { 
                                  year: 'numeric', 
                                  month: 'short', 
                                  day: 'numeric' 
                                })}
                              </span>
                            </div>
                            <p className="text-text-secondary mt-1 text-sm">
                              {reply.content}
                            </p>
                            <div className="flex items-center mt-2 text-text-secondary text-xs">
                              <button 
                                className="flex items-center mr-4 hover:text-text-primary"
                                onClick={() => handleVote(reply.id, true)}
                              >
                                <ThumbsUp className="mr-1 h-3 w-3" /> {reply.likes || 0}
                              </button>
                              <button 
                                className="flex items-center mr-4 hover:text-text-primary"
                                onClick={() => handleVote(reply.id, false)}
                              >
                                <ThumbsDown className="mr-1 h-3 w-3" /> {reply.dislikes || 0}
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
          
          {comments.length > visibleCount && (
            <Button 
              variant="secondary" 
              className="w-full py-3 bg-secondary hover:bg-opacity-80 text-text-primary font-medium rounded-lg transition-colors mt-4"
              onClick={handleLoadMore}
            >
              Load More Comments
            </Button>
          )}
        </div>
      )}
    </div>
  );
};

export default CommentSection;
