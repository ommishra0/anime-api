import {
  Play,
  Pause,
  Volume2,
  Volume1,
  VolumeX,
  SkipBack,
  SkipForward,
  Maximize,
  Subtitles
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface VideoControlsProps {
  show: boolean;
  playing: boolean;
  volume: number;
  played: number;
  duration: number;
  playbackRate: number;
  qualityOptions: string[];
  selectedQuality: string;
  formatTime: (seconds: number) => string;
  onPlayPause: () => void;
  onVolumeChange: (value: number) => void;
  onSeekChange: (value: number) => void;
  onSeekMouseDown: () => void;
  onSeekMouseUp: (value: number) => void;
  onPlaybackRateChange: (value: number) => void;
  onQualityChange: (value: string) => void;
  onFullscreen: () => void;
  onRewind: () => void;
  onFastForward: () => void;
}

const VideoControls = ({
  show,
  playing,
  volume,
  played,
  duration,
  playbackRate,
  qualityOptions,
  selectedQuality,
  formatTime,
  onPlayPause,
  onVolumeChange,
  onSeekChange,
  onSeekMouseDown,
  onSeekMouseUp,
  onPlaybackRateChange,
  onQualityChange,
  onFullscreen,
  onRewind,
  onFastForward
}: VideoControlsProps) => {
  // Get volume icon based on volume level
  const getVolumeIcon = () => {
    if (volume === 0) return <VolumeX className="h-5 w-5" />;
    if (volume < 0.5) return <Volume1 className="h-5 w-5" />;
    return <Volume2 className="h-5 w-5" />;
  };

  return (
    <div 
      className={`absolute bottom-0 left-0 right-0 video-player-controls p-4 bg-gradient-to-t from-black to-transparent transition-opacity duration-300 ${show ? 'opacity-100' : 'opacity-0'}`}
    >
      <div className="flex items-center mb-2">
        <Slider
          value={[played * 100]}
          min={0}
          max={100}
          step={0.1}
          onValueChange={(value) => onSeekChange(value[0] / 100)}
          onValueCommit={(value) => onSeekMouseUp(value[0] / 100)}
          className="w-full mr-2"
        />
        <span className="text-white text-sm whitespace-nowrap">
          {formatTime(played * duration)} / {formatTime(duration)}
        </span>
      </div>
      
      <div className="flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={onPlayPause} 
            className="text-white hover:bg-white/20"
          >
            {playing ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
          </Button>
          
          <div className="flex items-center space-x-2">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => onVolumeChange(volume === 0 ? 0.5 : 0)} 
              className="text-white hover:bg-white/20"
            >
              {getVolumeIcon()}
            </Button>
            <Slider
              value={[volume * 100]}
              min={0}
              max={100}
              step={1}
              onValueChange={(value) => onVolumeChange(value[0] / 100)}
              className="w-20 hidden md:block"
            />
          </div>
          
          <div className="hidden md:flex items-center space-x-3">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={onRewind} 
              className="text-white hover:bg-white/20 px-2 py-1 h-auto"
            >
              <SkipBack className="h-4 w-4 mr-1" /> 10s
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={onFastForward} 
              className="text-white hover:bg-white/20 px-2 py-1 h-auto"
            >
              <SkipForward className="h-4 w-4 mr-1" /> 10s
            </Button>
          </div>
        </div>
        
        <div className="flex items-center space-x-3">
          {qualityOptions.length > 1 && (
            <div className="hidden md:block">
              <Select
                value={selectedQuality}
                onValueChange={onQualityChange}
              >
                <SelectTrigger className="bg-black/50 text-white border-0 focus:ring-0 h-8 text-xs">
                  <SelectValue placeholder="Quality" />
                </SelectTrigger>
                <SelectContent className="bg-secondary text-text-primary border-secondary">
                  {qualityOptions.map(quality => (
                    <SelectItem key={quality} value={quality}>{quality}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
          
          <div>
            <Select
              value={playbackRate.toString()}
              onValueChange={(value) => onPlaybackRateChange(parseFloat(value))}
            >
              <SelectTrigger className="bg-black/50 text-white border-0 focus:ring-0 h-8 text-xs">
                <SelectValue placeholder="Speed" />
              </SelectTrigger>
              <SelectContent className="bg-secondary text-text-primary border-secondary">
                <SelectItem value="0.5">0.5x</SelectItem>
                <SelectItem value="0.75">0.75x</SelectItem>
                <SelectItem value="1">1x</SelectItem>
                <SelectItem value="1.25">1.25x</SelectItem>
                <SelectItem value="1.5">1.5x</SelectItem>
                <SelectItem value="2">2x</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <Button 
            variant="ghost" 
            size="icon" 
            className="text-white hover:bg-white/20"
          >
            <Subtitles className="h-5 w-5" />
          </Button>
          
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={onFullscreen} 
            className="text-white hover:bg-white/20"
          >
            <Maximize className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default VideoControls;
