import { useState, useRef, useEffect } from 'react';
import ReactPlayer from 'react-player';
import { Skeleton } from '@/components/ui/skeleton';
import VideoControls from './VideoControls';
import { Episode } from '@shared/schema';

interface VideoPlayerProps {
  episode: Episode | null;
  isLoading: boolean;
  autoPlay?: boolean;
  onVideoEnd?: () => void;
}

const VideoPlayer = ({ episode, isLoading, autoPlay = true, onVideoEnd }: VideoPlayerProps) => {
  const [showControls, setShowControls] = useState(false);
  const [playing, setPlaying] = useState(autoPlay);
  const [volume, setVolume] = useState(0.8);
  const [played, setPlayed] = useState(0);
  const [seeking, setSeeking] = useState(false);
  const [duration, setDuration] = useState(0);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [selectedQuality, setSelectedQuality] = useState<string>('1080p');
  const playerRef = useRef<ReactPlayer>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Quality options based on available video sources
  const getQualityOptions = () => {
    if (!episode) return [];
    
    const options = [];
    if (episode.video_1080p) options.push('1080p');
    if (episode.video_720p) options.push('720p');
    if (episode.video_480p) options.push('480p');
    if (episode.video_embed) options.push('Auto');
    
    return options.length ? options : ['Auto'];
  };

  // Get video URL based on selected quality
  const getVideoUrl = () => {
    if (!episode) return '';
    
    switch (selectedQuality) {
      case '1080p': return episode.video_1080p || '';
      case '720p': return episode.video_720p || '';
      case '480p': return episode.video_480p || '';
      default: return episode.video_embed || '';
    }
  };

  // Format time in MM:SS
  const formatTime = (seconds: number) => {
    const date = new Date(seconds * 1000);
    const mm = date.getUTCMinutes();
    const ss = date.getUTCSeconds().toString().padStart(2, '0');
    return `${mm}:${ss}`;
  };

  // Handle seeking
  const handleSeekChange = (newValue: number) => {
    setPlayed(newValue);
  };

  const handleSeekMouseDown = () => {
    setSeeking(true);
    setPlaying(false);
  };

  const handleSeekMouseUp = (newValue: number) => {
    setSeeking(false);
    setPlaying(true);
    playerRef.current?.seekTo(newValue);
  };

  // Handle player progress
  const handleProgress = (state: { played: number; playedSeconds: number }) => {
    if (!seeking) {
      setPlayed(state.played);
    }
  };

  // Handle fullscreen
  const handleFullscreen = () => {
    if (document.fullscreenElement) {
      document.exitFullscreen();
    } else {
      containerRef.current?.requestFullscreen();
    }
  };

  if (isLoading) {
    return (
      <div className="relative bg-black" style={{ aspectRatio: '16 / 9' }}>
        <Skeleton className="w-full h-full" />
      </div>
    );
  }

  if (!episode) {
    return (
      <div className="relative bg-black flex items-center justify-center" style={{ aspectRatio: '16 / 9' }}>
        <p className="text-white">Episode not found</p>
      </div>
    );
  }

  return (
    <div 
      className="relative video-player-container bg-black overflow-hidden"
      style={{ aspectRatio: '16 / 9' }}
      onMouseEnter={() => setShowControls(true)}
      onMouseLeave={() => setShowControls(false)}
      ref={containerRef}
    >
      <ReactPlayer
        ref={playerRef}
        url={getVideoUrl()}
        width="100%"
        height="100%"
        playing={playing}
        volume={volume}
        playbackRate={playbackRate}
        onProgress={handleProgress}
        onDuration={setDuration}
        onEnded={onVideoEnd}
        config={{
          file: {
            attributes: {
              controlsList: 'nodownload',
            },
          },
        }}
        style={{ position: 'absolute', top: 0, left: 0 }}
      />
      
      <VideoControls
        show={showControls}
        playing={playing}
        volume={volume}
        played={played}
        duration={duration}
        playbackRate={playbackRate}
        qualityOptions={getQualityOptions()}
        selectedQuality={selectedQuality}
        formatTime={formatTime}
        onPlayPause={() => setPlaying(!playing)}
        onVolumeChange={setVolume}
        onSeekChange={handleSeekChange}
        onSeekMouseDown={handleSeekMouseDown}
        onSeekMouseUp={handleSeekMouseUp}
        onPlaybackRateChange={setPlaybackRate}
        onQualityChange={setSelectedQuality}
        onFullscreen={handleFullscreen}
        onRewind={() => playerRef.current?.seekTo(Math.max(0, playerRef.current.getCurrentTime() - 10))}
        onFastForward={() => playerRef.current?.seekTo(Math.min(duration, playerRef.current.getCurrentTime() + 10))}
      />
    </div>
  );
};

export default VideoPlayer;
