import { useState } from 'react';
import { Link } from 'wouter';
import { Play, Plus, Share, Star, StarHalf, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Anime } from '@shared/schema';

interface AnimeInfoProps {
  anime: Anime | null;
  isLoading: boolean;
}

const AnimeInfo = ({ anime, isLoading }: AnimeInfoProps) => {
  const renderRatingStars = (rating: string) => {
    const numRating = parseFloat(rating);
    const integerPart = Math.floor(numRating);
    const decimalPart = numRating - integerPart;
    const stars = [];

    // Full stars
    for (let i = 0; i < integerPart; i++) {
      stars.push(<Star key={`full-${i}`} className="text-yellow-400 h-5 w-5" />);
    }

    // Half star if needed
    if (decimalPart >= 0.5) {
      stars.push(<StarHalf key="half" className="text-yellow-400 h-5 w-5" />);
    }

    return stars;
  };

  if (isLoading) {
    return (
      <div className="bg-surface rounded-xl overflow-hidden shadow-lg mb-8">
        <Skeleton className="w-full h-[400px]" />
        <div className="relative -mt-36 px-4 md:px-8 pb-6">
          <div className="flex flex-col md:flex-row">
            <Skeleton className="w-40 h-56 rounded-lg shadow-2xl mb-4 md:mb-0" />
            <div className="md:ml-8 pt-4 md:pt-32">
              <Skeleton className="h-8 w-64 mb-2" />
              <Skeleton className="h-6 w-full max-w-md mb-4" />
              <Skeleton className="h-10 w-32 rounded-full" />
            </div>
          </div>
          <div className="py-6">
            <Skeleton className="h-6 w-32 mb-3" />
            <Skeleton className="h-4 w-full mb-2" />
            <Skeleton className="h-4 w-full mb-2" />
            <Skeleton className="h-4 w-3/4 mb-6" />
          </div>
        </div>
      </div>
    );
  }

  if (!anime) {
    return <div className="text-center py-10">Anime information not found</div>;
  }

  return (
    <div className="bg-surface rounded-xl overflow-hidden shadow-lg mb-8">
      <div className="relative" style={{ height: '400px' }}>
        <img 
          src={anime.banner_image} 
          alt={`${anime.title} Banner`} 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-surface to-transparent"></div>
      </div>
      
      <div className="relative -mt-36 px-4 md:px-8">
        <div className="flex flex-col md:flex-row">
          <div className="w-40 h-56 rounded-lg overflow-hidden shadow-2xl mb-4 md:mb-0 shrink-0">
            <img 
              src={anime.cover_image} 
              alt={anime.title} 
              className="w-full h-full object-cover"
            />
          </div>
          
          <div className="md:ml-8 pt-4 md:pt-32">
            <div className="flex items-center mb-1">
              <span className="bg-primary text-white text-xs px-2 py-1 rounded mr-2">{anime.type}</span>
              <span className="text-text-secondary text-sm">
                {anime.release_year} • {anime.type === 'TV' ? 'Episodes' : anime.type} • {anime.genres.join(', ')}
              </span>
            </div>
            <h1 className="text-3xl md:text-4xl font-bold font-inter mb-2">{anime.title}</h1>
            
            <div className="flex items-center mb-4">
              <div className="flex mr-4">
                {renderRatingStars(anime.rating || '0')}
                <span className="ml-2 text-text-primary">{anime.rating}</span>
              </div>
              <div className="flex items-center text-text-secondary text-sm">
                <User className="h-4 w-4 mr-1" /> 240,521 Users
              </div>
            </div>
            
            <div className="flex space-x-3 mb-6">
              <Link href={`/watch/${anime.id}/1`}>
                <Button className="bg-primary hover:bg-opacity-80 text-white font-medium transition-colors">
                  <Play className="mr-2 h-4 w-4" /> Watch Now
                </Button>
              </Link>
              <Button variant="secondary" className="bg-secondary hover:bg-opacity-80 text-text-primary font-medium transition-colors">
                <Plus className="mr-2 h-4 w-4" /> Add to List
              </Button>
              <Button variant="secondary" className="bg-secondary hover:bg-opacity-80 text-text-primary font-medium transition-colors">
                <Share className="mr-2 h-4 w-4" /> Share
              </Button>
            </div>
          </div>
        </div>
        
        <div className="py-6">
          <h2 className="text-xl font-bold font-inter mb-3">Synopsis</h2>
          <p className="text-text-secondary mb-6">
            {anime.synopsis}
          </p>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <div>
              <h3 className="font-medium text-sm text-text-secondary mb-1">Studios</h3>
              <p>{anime.studios || 'Unknown'}</p>
            </div>
            <div>
              <h3 className="font-medium text-sm text-text-secondary mb-1">Director</h3>
              <p>{anime.director || 'Unknown'}</p>
            </div>
            <div>
              <h3 className="font-medium text-sm text-text-secondary mb-1">Original Title</h3>
              <p>{anime.alternative_title || anime.title}</p>
            </div>
            <div>
              <h3 className="font-medium text-sm text-text-secondary mb-1">Status</h3>
              <p>{anime.status}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnimeInfo;
