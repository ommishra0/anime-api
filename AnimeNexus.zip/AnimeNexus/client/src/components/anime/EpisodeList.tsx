import { useState } from 'react';
import { Link } from 'wouter';
import { Play, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Episode } from '@shared/schema';

interface EpisodeListProps {
  animeId: number;
  episodes: Episode[];
  isLoading: boolean;
}

const EpisodeList = ({ animeId, episodes, isLoading }: EpisodeListProps) => {
  const [selectedSeason, setSelectedSeason] = useState<string>("1");
  
  // Get unique seasons
  const seasons = episodes && episodes.length 
    ? [...new Set(episodes.map(episode => episode.season_number.toString()))]
    : ["1"];
  
  // Filter episodes by selected season
  const filteredEpisodes = episodes.filter(
    episode => episode.season_number.toString() === selectedSeason
  );
  
  // Used for "load more" functionality
  const [visibleCount, setVisibleCount] = useState(3);
  
  const handleLoadMore = () => {
    setVisibleCount(prev => prev + 3);
  };

  if (isLoading) {
    return (
      <div className="bg-surface rounded-xl p-6 mb-8 shadow-lg">
        <div className="flex justify-between items-center mb-6">
          <Skeleton className="h-6 w-32" />
          <Skeleton className="h-10 w-36" />
        </div>
        
        <div className="space-y-4">
          {[1, 2, 3].map(index => (
            <div key={index} className="bg-secondary rounded-lg overflow-hidden flex flex-col md:flex-row">
              <Skeleton className="w-full md:w-48 h-36" />
              <div className="p-4 w-full">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <Skeleton className="h-5 w-24 mb-1" />
                    <Skeleton className="h-6 w-48 mb-1" />
                  </div>
                  <Skeleton className="h-4 w-16" />
                </div>
                <Skeleton className="h-4 w-full mb-3" />
                <Skeleton className="h-4 w-3/4 mb-3" />
                <div className="flex justify-between items-center">
                  <Skeleton className="h-4 w-32" />
                  <Skeleton className="h-6 w-24" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (!episodes || episodes.length === 0) {
    return (
      <div className="bg-surface rounded-xl p-6 mb-8 shadow-lg">
        <h2 className="text-xl font-bold font-inter mb-6">Episodes</h2>
        <div className="text-center py-8 text-text-secondary">
          No episodes available for this anime yet.
        </div>
      </div>
    );
  }

  return (
    <div className="bg-surface rounded-xl p-6 mb-8 shadow-lg">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold font-inter">Episodes</h2>
        {seasons.length > 1 && (
          <div className="flex items-center">
            <label className="mr-3 text-text-secondary">Season</label>
            <Select
              value={selectedSeason}
              onValueChange={setSelectedSeason}
            >
              <SelectTrigger className="bg-secondary rounded w-[150px]">
                <SelectValue placeholder="Select Season" />
              </SelectTrigger>
              <SelectContent>
                {seasons.map(season => (
                  <SelectItem key={season} value={season}>
                    Season {season}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}
      </div>
      
      <div className="space-y-4">
        {filteredEpisodes.slice(0, visibleCount).map((episode) => (
          <div key={episode.id} className="bg-secondary rounded-lg overflow-hidden flex flex-col md:flex-row">
            <div className="w-full md:w-48 h-36 relative shrink-0">
              <img 
                src={episode.thumbnail} 
                alt={`Episode ${episode.episode_number}`} 
                className="w-full h-full object-cover"
                loading="lazy"
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <Link href={`/watch/${animeId}/${episode.id}`}>
                  <Button 
                    className="bg-primary/80 hover:bg-primary text-white rounded-full w-12 h-12 flex items-center justify-center transition-colors"
                    size="icon"
                  >
                    <Play className="h-5 w-5" />
                  </Button>
                </Link>
              </div>
            </div>
            <div className="p-4">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h3 className="font-medium">Episode {episode.episode_number}</h3>
                  <h4 className="text-lg font-bold">{episode.title}</h4>
                </div>
                <span className="text-text-secondary text-sm">{episode.duration}</span>
              </div>
              <p className="text-text-secondary text-sm mb-3 line-clamp-2">
                {episode.description || 'No description available.'}
              </p>
              <div className="flex justify-between items-center">
                <div className="flex items-center text-text-secondary text-xs">
                  <span>{new Date(episode.release_date).toLocaleDateString()}</span>
                  <span className="mx-2">•</span>
                  <span>Subbed</span>
                </div>
                <Link href={`/watch/${animeId}/${episode.id}`}>
                  <Button 
                    variant="link" 
                    className="text-primary hover:underline flex items-center text-sm p-0"
                  >
                    Watch Now <ChevronRight className="ml-1 h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        ))}
        
        {filteredEpisodes.length > visibleCount && (
          <Button 
            variant="secondary" 
            className="w-full py-3 bg-secondary hover:bg-opacity-80 text-text-primary font-medium rounded-lg transition-colors mt-4"
            onClick={handleLoadMore}
          >
            Load More Episodes
          </Button>
        )}
      </div>
    </div>
  );
};

export default EpisodeList;
