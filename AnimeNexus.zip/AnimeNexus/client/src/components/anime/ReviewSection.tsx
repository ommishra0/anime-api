import { useState } from 'react';
import { User, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Review, User as UserType } from '@shared/schema';
import { useAuth } from '@/context/AuthContext';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface ReviewSectionProps {
  animeId: number;
  reviews: (Review & { user: UserType })[];
  isLoading: boolean;
  refetch: () => void;
}

const reviewSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters"),
  content: z.string().min(10, "Review must be at least 10 characters"),
  rating: z.number().min(1).max(5),
});

type ReviewFormValues = z.infer<typeof reviewSchema>;

const ReviewSection = ({ animeId, reviews, isLoading, refetch }: ReviewSectionProps) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [visibleCount, setVisibleCount] = useState(3);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedRating, setSelectedRating] = useState(0);

  const form = useForm<ReviewFormValues>({
    resolver: zodResolver(reviewSchema),
    defaultValues: {
      title: "",
      content: "",
      rating: 0,
    },
  });

  const handleLoadMore = () => {
    setVisibleCount(prev => prev + 3);
  };

  const onSubmit = async (data: ReviewFormValues) => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please log in to submit a review",
        variant: "destructive",
      });
      return;
    }

    try {
      await apiRequest('POST', '/api/reviews', {
        anime_id: animeId,
        user_id: user.id,
        ...data,
      });
      
      toast({
        title: "Review submitted",
        description: "Thank you for your feedback!",
      });
      
      form.reset();
      setSelectedRating(0);
      setIsDialogOpen(false);
      refetch();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to submit review. Please try again.",
        variant: "destructive",
      });
    }
  };

  const renderStars = (rating: number) => {
    return Array(5).fill(0).map((_, i) => (
      <Star 
        key={i} 
        className={`${i < rating ? 'text-yellow-400' : 'text-gray-400'} h-4 w-4`} 
      />
    ));
  };

  const renderRatingSelector = () => {
    return (
      <div className="flex items-center mb-4">
        {Array(5).fill(0).map((_, i) => (
          <Star 
            key={i} 
            className={`h-6 w-6 cursor-pointer ${i < selectedRating ? 'text-yellow-400' : 'text-gray-400'}`}
            onClick={() => {
              setSelectedRating(i + 1);
              form.setValue('rating', i + 1);
            }}
          />
        ))}
      </div>
    );
  };

  if (isLoading) {
    return (
      <div className="bg-surface rounded-xl p-6 shadow-lg">
        <div className="flex justify-between items-center mb-6">
          <Skeleton className="h-6 w-40" />
          <Skeleton className="h-10 w-32" />
        </div>
        
        <div className="space-y-6">
          {[1, 2, 3].map(index => (
            <div key={index} className="border-b border-secondary pb-6">
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center">
                  <Skeleton className="w-10 h-10 rounded-full mr-3" />
                  <div>
                    <Skeleton className="h-5 w-32 mb-1" />
                    <Skeleton className="h-4 w-24" />
                  </div>
                </div>
                <Skeleton className="h-4 w-20" />
              </div>
              <Skeleton className="h-6 w-48 mb-2" />
              <Skeleton className="h-4 w-full mb-1" />
              <Skeleton className="h-4 w-full mb-1" />
              <Skeleton className="h-4 w-2/3" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-surface rounded-xl p-6 shadow-lg">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold font-inter">User Reviews</h2>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-opacity-80 text-white font-medium transition-colors">
              Write a Review
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-surface text-text-primary border-secondary">
            <DialogHeader>
              <DialogTitle className="text-lg font-bold">Write a Review</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="rating"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Rating</FormLabel>
                      <FormControl>
                        <div {...field} className="focus:outline-none">
                          {renderRatingSelector()}
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Title</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Review title" 
                          className="bg-secondary text-text-primary" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="content"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Your Review</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Write your thoughts..." 
                          className="bg-secondary text-text-primary resize-none" 
                          rows={5} 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="flex justify-end">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setIsDialogOpen(false)}
                    className="mr-2"
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit" 
                    className="bg-primary text-white"
                    disabled={form.formState.isSubmitting}
                  >
                    Submit Review
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
      
      {reviews.length === 0 ? (
        <div className="text-center py-8 text-text-secondary">
          No reviews yet. Be the first to write one!
        </div>
      ) : (
        <div className="space-y-6">
          {reviews.slice(0, visibleCount).map((review) => (
            <div key={review.id} className="border-b border-secondary pb-6">
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center">
                  <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center mr-3">
                    <span className="text-primary font-bold">
                      {review.user.username.substring(0, 2).toUpperCase()}
                    </span>
                  </div>
                  <div>
                    <h3 className="font-medium">{review.user.username}</h3>
                    <div className="flex">
                      {renderStars(review.rating)}
                    </div>
                  </div>
                </div>
                <span className="text-text-secondary text-sm">
                  {new Date(review.created_at).toLocaleDateString()}
                </span>
              </div>
              <h4 className="font-bold mb-2">{review.title}</h4>
              <p className="text-text-secondary">
                {review.content}
              </p>
            </div>
          ))}
          
          {reviews.length > visibleCount && (
            <Button 
              variant="secondary" 
              className="w-full py-3 bg-secondary hover:bg-opacity-80 text-text-primary font-medium rounded-lg transition-colors mt-4"
              onClick={handleLoadMore}
            >
              Load More Reviews
            </Button>
          )}
        </div>
      )}
    </div>
  );
};

export default ReviewSection;
