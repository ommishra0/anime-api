import { Link } from 'wouter';
import { ChevronRight } from 'lucide-react';
import AnimeCard from './AnimeCard';
import { Skeleton } from '@/components/ui/skeleton';
import { Anime } from '@shared/schema';

interface AnimeSectionProps {
  title: string;
  animes: Anime[];
  viewAllLink: string;
  isLoading: boolean;
}

const AnimeSection = ({ title, animes, viewAllLink, isLoading }: AnimeSectionProps) => {
  return (
    <div className="mb-12">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold font-inter">{title}</h2>
        <Link href={viewAllLink} className="text-primary hover:underline flex items-center">
          View All <ChevronRight className="ml-1 h-4 w-4" />
        </Link>
      </div>
      
      {isLoading ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {[...Array(5)].map((_, index) => (
            <div key={index} className="rounded-lg overflow-hidden shadow-lg">
              <Skeleton className="w-full h-48" />
              <div className="p-3 bg-surface">
                <Skeleton className="h-5 w-3/4 mb-2" />
                <Skeleton className="h-4 w-1/2" />
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {animes.map((anime) => (
            <AnimeCard key={anime.id} anime={anime} />
          ))}
        </div>
      )}
    </div>
  );
};

export default AnimeSection;
