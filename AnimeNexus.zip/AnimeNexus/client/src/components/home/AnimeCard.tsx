import { Link } from 'wouter';
import { Star } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Anime } from '@shared/schema';

interface AnimeCardProps {
  anime: Anime;
  showBadge?: boolean;
  badgeText?: string;
}

const AnimeCard = ({ anime, showBadge = false, badgeText = 'NEW' }: AnimeCardProps) => {
  return (
    <Link href={`/anime/${anime.id}`}>
      <div className="anime-card bg-surface rounded-lg overflow-hidden shadow-lg transition-transform hover:translate-y-[-5px] hover:shadow-xl">
        <div className="relative">
          <img 
            src={anime.cover_image} 
            alt={anime.title} 
            className="w-full h-48 object-cover"
            loading="lazy"
          />
          {showBadge && (
            <div className="absolute top-2 left-2">
              <Badge className="bg-primary text-white text-xs">{badgeText}</Badge>
            </div>
          )}
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-3">
            <div className="flex items-center text-xs">
              <Star className="h-4 w-4 text-yellow-400 mr-1" />
              <span>{anime.rating}</span>
              <span className="mx-2">•</span>
              <span>{anime.type}</span>
              {anime.type === 'TV' && (
                <>
                  <span className="mx-2">•</span>
                  <span>{anime.status === 'Airing' ? 'AIRING' : 'COMPLETE'}</span>
                </>
              )}
            </div>
          </div>
        </div>
        <div className="p-3">
          <h3 className="font-medium text-base line-clamp-1">{anime.title}</h3>
          <p className="text-text-secondary text-xs">{anime.genres.slice(0, 2).join(', ')}</p>
        </div>
      </div>
    </Link>
  );
};

export default AnimeCard;
