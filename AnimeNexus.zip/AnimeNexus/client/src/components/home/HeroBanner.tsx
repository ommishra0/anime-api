import { useState, useEffect } from 'react';
import { Link } from 'wouter';
import { Play, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Anime } from '@shared/schema';

interface HeroBannerProps {
  featured: Anime | null;
  isLoading: boolean;
}

const HeroBanner = ({ featured, isLoading }: HeroBannerProps) => {
  if (isLoading) {
    return (
      <div className="relative rounded-xl overflow-hidden mb-10 shadow-xl" style={{ height: '500px' }}>
        <Skeleton className="w-full h-full" />
      </div>
    );
  }

  if (!featured) {
    return null;
  }

  return (
    <div className="relative rounded-xl overflow-hidden mb-10 shadow-xl" style={{ height: '500px' }}>
      <div 
        className="w-full h-full bg-cover bg-center"
        style={{ 
          backgroundImage: `url(${featured.banner_image})`,
          backgroundPosition: 'center',
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-r from-background via-background/80 to-transparent flex items-center">
        <div className="p-8 md:p-16 max-w-2xl">
          <div className="inline-block bg-primary text-white px-3 py-1 rounded-md text-sm font-bold mb-4">FEATURED</div>
          <h1 className="text-4xl md:text-5xl font-bold font-inter mb-3">{featured.title}</h1>
          <p className="text-text-secondary mb-6 line-clamp-3 md:line-clamp-4">
            {featured.synopsis}
          </p>
          <div className="flex space-x-4">
            <Link href={`/anime/${featured.id}`}>
              <Button className="bg-primary hover:bg-opacity-80 text-white font-medium transition-colors">
                <Play className="mr-2 h-4 w-4" /> Watch Now
              </Button>
            </Link>
            <Button variant="outline" className="bg-secondary hover:bg-opacity-80 text-text-primary font-medium transition-colors">
              <Plus className="mr-2 h-4 w-4" /> Add to List
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HeroBanner;
