import { Link } from 'wouter';
import { 
  LayoutDashboard, 
  Film, 
  PlusCircle, 
  PlayCircle, 
  Users, 
  Settings, 
  User,
  Database,
  FileVideo,
  Menu,
  X
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';

interface AdminSidebarProps {
  currentPage: string;
}

const AdminSidebar = ({ currentPage }: AdminSidebarProps) => {
  const { user } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    
    return () => {
      window.removeEventListener('resize', checkMobile);
    };
  }, []);
  
  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };
  
  const closeMenuOnMobile = () => {
    if (isMobile) {
      setIsMenuOpen(false);
    }
  };
  
  if (!user) return null;
  
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-5 h-5" />, path: '/admin' },
    
    // Content Management section
    { id: 'anime-list', label: 'Anime List', icon: <Film className="w-5 h-5" />, path: '/admin/anime-list' },
    { id: 'add-anime', label: 'Add Anime', icon: <PlusCircle className="w-5 h-5" />, path: '/admin/add-anime' },
    { id: 'import-tmdb', label: 'Import from TMDB', icon: <Database className="w-5 h-5" />, path: '/admin/import-tmdb' },
    
    // Episode Management section
    { id: 'episodes', label: 'Episodes', icon: <PlayCircle className="w-5 h-5" />, path: '/admin/episodes' },
    { id: 'add-episode', label: 'Add Episode', icon: <FileVideo className="w-5 h-5" />, path: '/admin/add-episode' },
    
    // Admin section
    { id: 'users', label: 'User Management', icon: <Users className="w-5 h-5" />, path: '/admin/users' },
    { id: 'settings', label: 'Settings', icon: <Settings className="w-5 h-5" />, path: '/admin/settings' },
  ];

  return (
    <>
      {/* Mobile Menu Toggle Button */}
      <div className="fixed top-2 right-4 z-50 md:hidden">
        <Button variant="outline" size="icon" className="rounded-full" onClick={toggleMenu}>
          {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </Button>
      </div>
      
      {/* Sidebar for desktop and mobile */}
      <div className={`
        fixed md:relative z-40 bg-surface border-r border-secondary h-full
        ${isMobile 
          ? isMenuOpen 
            ? 'w-64 translate-x-0 shadow-lg transition-transform duration-200' 
            : 'w-64 -translate-x-full transition-transform duration-200'
          : 'w-64 translate-x-0'
        }
        ${isMobile && !isMenuOpen ? 'hidden' : ''}
        md:block md:translate-x-0
      `}>
        <div className="p-4 h-full overflow-y-auto">
          <div className="flex items-center space-x-3 mb-8">
            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
              <User className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h3 className="font-medium">{user.username}</h3>
              <p className="text-text-secondary text-xs">{user.role}</p>
            </div>
          </div>
          
          <nav>
            <ul className="space-y-1">
              {menuItems.map(item => (
                <li key={item.id}>
                  <Link href={item.path}>
                    <a 
                      className={`admin-sidebar-item flex items-center py-2 px-3 rounded-lg transition-colors ${
                        currentPage === item.id 
                          ? 'bg-primary/10 border-l-3 border-primary'
                          : 'hover:bg-secondary'
                      }`}
                      onClick={closeMenuOnMobile}
                    >
                      <span className={`w-5 ${currentPage === item.id ? 'text-primary' : 'text-text-secondary'}`}>
                        {item.icon}
                      </span>
                      <span className={`ml-3 ${currentPage === item.id ? 'font-medium' : ''}`}>
                        {item.label}
                      </span>
                    </a>
                  </Link>
                </li>
              ))}
            </ul>
          </nav>
        </div>
      </div>
      
      {/* Overlay for mobile */}
      {isMobile && isMenuOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-30 md:hidden"
          onClick={toggleMenu}
        />
      )}
    </>
  );
};

export default AdminSidebar;
