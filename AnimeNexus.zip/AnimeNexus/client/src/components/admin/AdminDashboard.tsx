import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { 
  Film, 
  PlayCircle, 
  Users, 
  Database,
  ArrowUpRight,
  MoreVertical,
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

const AdminDashboard = () => {
  const { data: dashboardStats, isLoading: isLoadingStats } = useQuery({
    queryKey: ['/api/admin/stats'],
    refetchInterval: 60000, // Refresh every minute
  });

  const { data: recentUploads, isLoading: isLoadingUploads } = useQuery({
    queryKey: ['/api/admin/recent-uploads'],
  });

  const { data: userActivities, isLoading: isLoadingActivities } = useQuery({
    queryKey: ['/api/admin/user-activities'],
  });

  return (
    <>
      {/* Dashboard Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard 
          title="Total Anime" 
          value={dashboardStats?.animeCount || 0} 
          change={dashboardStats?.animeChange || 0} 
          icon={<Film className="text-primary" />}
          isLoading={isLoadingStats}
        />
        
        <StatCard 
          title="Total Episodes" 
          value={dashboardStats?.episodeCount || 0} 
          change={dashboardStats?.episodeChange || 0} 
          icon={<PlayCircle className="text-accent" />}
          isLoading={isLoadingStats}
        />
        
        <StatCard 
          title="Total Users" 
          value={dashboardStats?.userCount || 0} 
          change={dashboardStats?.userChange || 0} 
          icon={<Users className="text-blue-500" />}
          isLoading={isLoadingStats}
        />
        
        <StatCard 
          title="Storage Used" 
          value={`${dashboardStats?.storageUsed || '0'} GB`} 
          subtext={`${dashboardStats?.storagePercentage || 0}% of total capacity`}
          icon={<Database className="text-purple-500" />}
          showChangeAsPercent={false}
          isLoading={isLoadingStats}
        />
      </div>
      
      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <Card className="bg-surface shadow-lg border-none">
          <CardContent className="p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg font-bold font-inter">Recent Uploads</h2>
              <Link href="/admin/episodes">
                <Button variant="link" className="text-primary hover:underline text-sm p-0">
                  View All
                </Button>
              </Link>
            </div>
            
            <div className="space-y-4">
              {isLoadingUploads ? (
                Array(4).fill(0).map((_, index) => (
                  <div className="flex items-center" key={index}>
                    <Skeleton className="w-12 h-12 rounded-lg mr-3" />
                    <div className="flex-1">
                      <Skeleton className="h-5 w-3/4 mb-1" />
                      <Skeleton className="h-4 w-1/2" />
                    </div>
                    <Skeleton className="h-4 w-16" />
                  </div>
                ))
              ) : recentUploads && recentUploads.length > 0 ? (
                recentUploads.map((upload: any) => (
                  <div className="flex items-center" key={upload.id}>
                    <div className="w-12 h-12 rounded-lg overflow-hidden mr-3 shrink-0">
                      <img 
                        src={upload.thumbnail} 
                        alt={upload.title} 
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium line-clamp-1">{upload.anime_title}</h3>
                      <p className="text-text-secondary text-xs">
                        Episode {upload.episode_number} • Added {formatTimeAgo(upload.created_at)}
                      </p>
                    </div>
                    <div className="text-text-secondary text-sm">
                      {upload.quality || '1080p'}
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-4 text-text-secondary">
                  No recent uploads
                </div>
              )}
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-surface shadow-lg border-none">
          <CardContent className="p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg font-bold font-inter">User Activity</h2>
              <Link href="/admin/users">
                <Button variant="link" className="text-primary hover:underline text-sm p-0">
                  View All
                </Button>
              </Link>
            </div>
            
            <div className="space-y-4">
              {isLoadingActivities ? (
                Array(4).fill(0).map((_, index) => (
                  <div className="flex items-center" key={index}>
                    <Skeleton className="w-10 h-10 rounded-full mr-3" />
                    <div className="flex-1">
                      <Skeleton className="h-5 w-32 mb-1" />
                      <Skeleton className="h-4 w-48" />
                    </div>
                    <Skeleton className="h-8 w-8 rounded-full" />
                  </div>
                ))
              ) : userActivities && userActivities.length > 0 ? (
                userActivities.map((activity: any) => (
                  <div className="flex items-center" key={activity.id}>
                    <Avatar className="w-10 h-10 mr-3 shrink-0">
                      <AvatarFallback className={`bg-${getRandomColor()}/20 text-${getRandomColor()}`}>
                        {activity.username.substring(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <h3 className="font-medium">{activity.username}</h3>
                      <p className="text-text-secondary text-xs">
                        {activity.action} • {formatTimeAgo(activity.timestamp)}
                      </p>
                    </div>
                    <Button variant="ghost" size="icon" className="text-text-secondary hover:text-text-primary">
                      <MoreVertical className="h-5 w-5" />
                    </Button>
                  </div>
                ))
              ) : (
                <div className="text-center py-4 text-text-secondary">
                  No recent activity
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
};

// Helper component for dashboard stats
interface StatCardProps {
  title: string;
  value: number | string;
  change?: number;
  subtext?: string;
  icon: React.ReactNode;
  showChangeAsPercent?: boolean;
  isLoading?: boolean;
}

const StatCard = ({ 
  title, 
  value, 
  change, 
  subtext, 
  icon, 
  showChangeAsPercent = true,
  isLoading = false
}: StatCardProps) => {
  return (
    <Card className="bg-surface shadow-lg border-none">
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h2 className="text-text-secondary text-sm">{title}</h2>
            {isLoading ? (
              <Skeleton className="h-8 w-24 mt-1" />
            ) : (
              <p className="text-3xl font-bold font-inter">{value}</p>
            )}
          </div>
          <div className="bg-primary/20 p-3 rounded-lg">
            {icon}
          </div>
        </div>
        {isLoading ? (
          <Skeleton className="h-4 w-32" />
        ) : showChangeAsPercent && change !== undefined ? (
          <div className={`flex items-center text-sm ${change >= 0 ? 'text-accent' : 'text-error'}`}>
            {change >= 0 ? (
              <ArrowUpRight className="mr-1 h-4 w-4" />
            ) : (
              <ArrowUpRight className="mr-1 h-4 w-4 transform rotate-180" />
            )}
            <span>{Math.abs(change)}% {change >= 0 ? 'increase' : 'decrease'} this month</span>
          </div>
        ) : (
          <div className="text-text-secondary text-sm">
            {subtext}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// Helper function to format time ago from timestamp
const formatTimeAgo = (timestamp: string) => {
  const date = new Date(timestamp);
  const now = new Date();
  const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
  
  if (diffInSeconds < 60) return `${diffInSeconds} seconds ago`;
  if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)} minutes ago`;
  if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)} hours ago`;
  if (diffInSeconds < 604800) return `${Math.floor(diffInSeconds / 86400)} days ago`;
  
  return date.toLocaleDateString();
};

// Helper function to get a random color for avatar backgrounds
const getRandomColor = () => {
  const colors = ['primary', 'accent', 'error', 'blue', 'purple', 'green'];
  return colors[Math.floor(Math.random() * colors.length)];
};

export default AdminDashboard;
