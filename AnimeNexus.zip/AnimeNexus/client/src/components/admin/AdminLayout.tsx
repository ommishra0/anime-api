import { ReactNode } from 'react';
import AdminSidebar from './AdminSidebar';
import { useAuth } from '@/context/AuthContext';
import { Bell, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { useLocation } from 'wouter';

interface AdminLayoutProps {
  children: ReactNode;
  title: string;
  currentPage: string;
}

const AdminLayout = ({ children, title, currentPage }: AdminLayoutProps) => {
  const { user, logout } = useAuth();
  const { toast } = useToast();
  const [_, navigate] = useLocation();

  const handleLogout = async () => {
    await logout();
    navigate('/login');
    toast({
      title: "Logged out",
      description: "You have been logged out of the admin panel",
    });
  };

  if (!user || user.role !== 'admin') {
    return <div className="text-center py-10">Unauthorized access</div>;
  }

  return (
    <div className="flex flex-col md:flex-row min-h-screen -mt-20 pt-20 overflow-hidden">
      {/* Admin Sidebar */}
      <AdminSidebar currentPage={currentPage} />
      
      {/* Admin Content */}
      <div className="flex-1 overflow-auto bg-background h-[calc(100vh-80px)]">
        <div className="p-4 md:p-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold font-inter">{title}</h1>
            
            <div className="flex items-center space-x-2">
              <Button variant="secondary" size="icon" className="text-text-primary">
                <Bell className="h-5 w-5" />
              </Button>
              <Button 
                variant="primary" 
                className="bg-primary hover:bg-opacity-80 text-white"
                onClick={handleLogout}
              >
                <LogOut className="h-4 w-4 mr-2" /> Logout
              </Button>
            </div>
          </div>
          
          {children}
        </div>
      </div>
    </div>
  );
};

export default AdminLayout;
