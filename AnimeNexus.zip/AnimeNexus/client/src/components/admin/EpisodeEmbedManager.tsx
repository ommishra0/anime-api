import React from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Episode, Anime } from '@shared/schema';

import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue 
} from '@/components/ui/select';
import { Loader2, Film, Save } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const formSchema = z.object({
  anime_id: z.coerce.number().int().positive('Please select an anime'),
  title: z.string().min(3, 'Title must be at least 3 characters'),
  episode_number: z.coerce.number().int().positive('Episode number must be a positive integer'),
  season_number: z.coerce.number().int().positive('Season number must be a positive integer'),
  duration: z.string().min(3, 'Duration must be at least 3 characters').default('24:00'),
  thumbnail: z.string().url('Thumbnail must be a valid URL').optional().or(z.literal('')),
  video_embed: z.string().url('Embed URL must be a valid URL').optional().or(z.literal('')),
  video_480p: z.string().url('480p URL must be a valid URL').optional().or(z.literal('')),
  video_720p: z.string().url('720p URL must be a valid URL').optional().or(z.literal('')),
  video_1080p: z.string().url('1080p URL must be a valid URL').optional().or(z.literal('')),
  description: z.string().min(10, 'Description must be at least 10 characters'),
});

type FormData = z.infer<typeof formSchema>;

const EpisodeEmbedManager = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Get all animes for the dropdown
  const { data: animes, isLoading: isLoadingAnimes } = useQuery<Anime[]>({
    queryKey: ['/api/animes'],
    staleTime: 60 * 1000, // 1 minute
  });

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      anime_id: 0,
      title: '',
      episode_number: 1,
      season_number: 1,
      duration: '24:00',
      thumbnail: '',
      video_embed: '',
      video_480p: '',
      video_720p: '',
      video_1080p: '',
      description: '',
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const res = await apiRequest('POST', '/api/episodes', data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/episodes'] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/stats'] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/recent-uploads'] });
      toast({
        title: 'Success',
        description: 'Episode has been created successfully.',
      });
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to create episode.',
        variant: 'destructive',
      });
    }
  });

  const onSubmit = (data: FormData) => {
    createMutation.mutate(data);
  };

  const handleEmbedTypeChange = (value: string) => {
    // Clear any existing video URLs
    form.setValue('video_480p', '');
    form.setValue('video_720p', '');
    form.setValue('video_1080p', '');
    form.setValue('video_embed', '');
  };

  // Function to extract video ID from YouTube URL
  const getYoutubeEmbedURL = (url: string) => {
    if (!url) return '';
    
    // Handle youtube.com/watch?v= format
    let match = url.match(/youtube\.com\/watch\?v=([^&]+)/);
    if (match) return `https://www.youtube.com/embed/${match[1]}`;
    
    // Handle youtu.be/ format
    match = url.match(/youtu\.be\/([^?]+)/);
    if (match) return `https://www.youtube.com/embed/${match[1]}`;
    
    // If it already looks like an embed URL, return it
    if (url.includes('youtube.com/embed/')) return url;
    
    return url; // Return original if no pattern matched
  };

  // Helper to auto-convert pasted YouTube URLs to embed format
  const handlePasteYouTube = (e: React.ClipboardEvent) => {
    const pastedText = e.clipboardData.getData('text');
    if (pastedText.includes('youtube.com/watch?v=') || pastedText.includes('youtu.be/')) {
      e.preventDefault();
      form.setValue('video_embed', getYoutubeEmbedURL(pastedText));
    }
  };

  return (
    <div className="space-y-6 pb-20 overflow-y-auto max-h-[calc(100vh-120px)] md:max-h-full">
      <Card>
        <CardHeader>
          <CardTitle>Add New Episode</CardTitle>
          <CardDescription>
            Create a new episode with external video links or embed code
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="anime_id"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Anime</FormLabel>
                      <Select 
                        onValueChange={(value) => field.onChange(parseInt(value))}
                        value={field.value.toString()}
                        disabled={isLoadingAnimes}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select an anime" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {animes?.map((anime) => (
                            <SelectItem key={anime.id} value={anime.id.toString()}>
                              {anime.title}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormDescription>
                        Select the anime this episode belongs to
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Episode Title</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter episode title" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="season_number"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Season Number</FormLabel>
                      <FormControl>
                        <Input type="number" min="1" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="episode_number"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Episode Number</FormLabel>
                      <FormControl>
                        <Input type="number" min="1" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="duration"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Duration</FormLabel>
                      <FormControl>
                        <Input placeholder="24:00" {...field} />
                      </FormControl>
                      <FormDescription>
                        Format: MM:SS
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="thumbnail"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Thumbnail URL</FormLabel>
                    <FormControl>
                      <Input placeholder="https://example.com/thumbnail.jpg" {...field} />
                    </FormControl>
                    <FormDescription>
                      URL to the episode thumbnail image
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Tabs defaultValue="embed" onValueChange={handleEmbedTypeChange}>
                <TabsList className="grid grid-cols-2">
                  <TabsTrigger value="embed">Video Embed</TabsTrigger>
                  <TabsTrigger value="direct">Direct Video Links</TabsTrigger>
                </TabsList>
                
                <TabsContent value="embed" className="space-y-4">
                  <FormField
                    control={form.control}
                    name="video_embed"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Video Embed URL</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="https://www.youtube.com/embed/VIDEO_ID" 
                            {...field} 
                            onPaste={handlePasteYouTube}
                          />
                        </FormControl>
                        <FormDescription>
                          YouTube embed URL. You can paste a regular YouTube URL and it will be converted.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  {form.watch('video_embed') && (
                    <div className="border rounded-md p-4">
                      <h3 className="text-sm font-medium mb-2">Embed Preview</h3>
                      <div className="aspect-video">
                        <iframe 
                          src={form.watch('video_embed')} 
                          className="w-full h-full rounded-md"
                          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                          allowFullScreen
                        ></iframe>
                      </div>
                    </div>
                  )}
                </TabsContent>
                
                <TabsContent value="direct" className="space-y-4">
                  <FormField
                    control={form.control}
                    name="video_480p"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>480p Video URL</FormLabel>
                        <FormControl>
                          <Input placeholder="https://example.com/video-480p.mp4" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="video_720p"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>720p Video URL</FormLabel>
                        <FormControl>
                          <Input placeholder="https://example.com/video-720p.mp4" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="video_1080p"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>1080p Video URL</FormLabel>
                        <FormControl>
                          <Input placeholder="https://example.com/video-1080p.mp4" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </TabsContent>
              </Tabs>

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Episode Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Enter a description of this episode" 
                        className="min-h-[100px]"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button 
                type="submit" 
                disabled={createMutation.isPending}
                className="w-full"
              >
                {createMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Creating Episode...
                  </>
                ) : (
                  <>
                    <Film className="mr-2 h-4 w-4" />
                    Create Episode
                  </>
                )}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
};

export default EpisodeEmbedManager;