import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Anime } from '@shared/schema';

import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, Search } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const formSchema = z.object({
  tmdbId: z.coerce.number().int().positive('TMDB ID must be a positive integer')
});

type FormData = z.infer<typeof formSchema>;

const ImportFromTMDB = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      tmdbId: 0,
    },
  });

  const importMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const res = await apiRequest('POST', '/api/tmdb/import', data);
      return await res.json();
    },
    onSuccess: (data: { data: Anime }) => {
      queryClient.invalidateQueries({ queryKey: ['/api/animes'] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/stats'] });
      toast({
        title: 'Success',
        description: `${data.data.title} has been imported successfully.`,
      });
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to import anime from TMDB.',
        variant: 'destructive',
      });
    }
  });

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    
    setIsSearching(true);
    try {
      const response = await fetch(`/api/tmdb/search?q=${encodeURIComponent(searchQuery)}`);
      if (!response.ok) throw new Error('Search failed');
      
      const results = await response.json();
      setSearchResults(results);
    } catch (error) {
      console.error('Search error:', error);
      toast({
        title: 'Search failed',
        description: 'Could not search TMDB. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsSearching(false);
    }
  };

  const selectAnime = (tmdbId: number) => {
    form.setValue('tmdbId', tmdbId);
  };

  const onSubmit = (data: FormData) => {
    importMutation.mutate(data);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Import Anime from TMDB</CardTitle>
          <CardDescription>
            Search and import anime directly from The Movie Database (TMDB).
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Input
                placeholder="Search for anime..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1"
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              />
              <Button type="button" onClick={handleSearch} disabled={isSearching}>
                {isSearching ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Search className="h-4 w-4 mr-2" />}
                Search
              </Button>
            </div>

            {searchResults.length > 0 && (
              <div className="space-y-4 max-h-96 overflow-y-auto p-2 border rounded-md">
                <h3 className="font-medium text-sm text-muted-foreground">Search Results</h3>
                <div className="grid grid-cols-1 gap-4">
                  {searchResults.map((result) => (
                    <div
                      key={result.id}
                      className="flex items-center p-2 rounded-md hover:bg-accent cursor-pointer"
                      onClick={() => selectAnime(result.id)}
                    >
                      {result.poster_path && (
                        <img
                          src={`https://image.tmdb.org/t/p/w92${result.poster_path}`}
                          alt={result.title || result.name}
                          className="w-16 h-auto rounded-md mr-4"
                        />
                      )}
                      <div>
                        <h4 className="font-medium">{result.title || result.name}</h4>
                        <p className="text-sm text-muted-foreground">
                          {result.first_air_date || result.release_date
                            ? new Date(result.first_air_date || result.release_date).getFullYear()
                            : 'Unknown year'}
                        </p>
                        {result.overview && (
                          <p className="text-sm line-clamp-2 mt-1">{result.overview}</p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="tmdbId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>TMDB ID</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter TMDB ID" {...field} />
                      </FormControl>
                      <FormDescription>
                        Enter the TMDB ID or select an anime from the search results
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button 
                  type="submit" 
                  disabled={importMutation.isPending}
                  className="w-full"
                >
                  {importMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Importing...
                    </>
                  ) : (
                    'Import Anime'
                  )}
                </Button>
              </form>
            </Form>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ImportFromTMDB;