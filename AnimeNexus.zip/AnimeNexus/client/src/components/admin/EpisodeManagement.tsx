import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  Search, 
  Plus, 
  PlayCircle, 
  Edit, 
  Trash2,
  ChevronLeft,
  ChevronRight,
  Upload,
  X
} from 'lucide-react';
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from '@/components/ui/form';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Episode, insertEpisodeSchema, Anime } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { uploadFile } from '@/lib/supabase';
import { z } from 'zod';

const formSchema = insertEpisodeSchema.extend({
  thumbnailFile: z.instanceof(File).optional(),
});

type FormData = z.infer<typeof formSchema>;

const ITEMS_PER_PAGE = 10;

const EpisodeManagement = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedAnime, setSelectedAnime] = useState<number | null>(null);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [currentSeason, setCurrentSeason] = useState<number>(1);
  const [thumbnailPreview, setThumbnailPreview] = useState<string | null>(null);
  const [episodeToDelete, setEpisodeToDelete] = useState<Episode | null>(null);
  const [editEpisode, setEditEpisode] = useState<Episode | null>(null);

  const { data: animes, isLoading: isLoadingAnimes } = useQuery({
    queryKey: ['/api/animes'],
  });

  const { data: episodes, isLoading: isLoadingEpisodes } = useQuery({
    queryKey: ['/api/episodes', selectedAnime],
    enabled: !!selectedAnime,
  });

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      anime_id: 0,
      title: '',
      episode_number: 1,
      season_number: 1,
      duration: '24:00',
      thumbnail: '',
      video_1080p: '',
      video_720p: '',
      video_480p: '',
      video_embed: '',
      description: '',
    }
  });

  const addEpisodeMutation = useMutation({
    mutationFn: async (data: FormData) => {
      let thumbnailUrl = data.thumbnail;
      
      if (data.thumbnailFile) {
        const fileName = `episode_thumbnails/${Date.now()}_${data.thumbnailFile.name}`;
        thumbnailUrl = await uploadFile('anime-images', fileName, data.thumbnailFile);
      }
      
      const episodeData = {
        ...data,
        thumbnail: thumbnailUrl,
      };
      
      delete episodeData.thumbnailFile;
      
      return apiRequest('POST', '/api/episodes', episodeData);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Episode added successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/episodes', selectedAnime] });
      form.reset();
      setThumbnailPreview(null);
      setIsAddDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to add episode. Please try again.",
        variant: "destructive",
      });
      console.error("Error adding episode:", error);
    }
  });

  const updateEpisodeMutation = useMutation({
    mutationFn: async (data: FormData & { id: number }) => {
      const { id, ...episodeData } = data;
      let thumbnailUrl = episodeData.thumbnail;
      
      if (data.thumbnailFile) {
        const fileName = `episode_thumbnails/${Date.now()}_${data.thumbnailFile.name}`;
        thumbnailUrl = await uploadFile('anime-images', fileName, data.thumbnailFile);
      }
      
      const updatedData = {
        ...episodeData,
        thumbnail: thumbnailUrl,
      };
      
      delete updatedData.thumbnailFile;
      
      return apiRequest('PUT', `/api/episodes/${id}`, updatedData);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Episode updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/episodes', selectedAnime] });
      form.reset();
      setThumbnailPreview(null);
      setEditEpisode(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update episode. Please try again.",
        variant: "destructive",
      });
      console.error("Error updating episode:", error);
    }
  });

  const deleteEpisodeMutation = useMutation({
    mutationFn: (episodeId: number) => {
      return apiRequest('DELETE', `/api/episodes/${episodeId}`, {});
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Episode deleted successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/episodes', selectedAnime] });
      setEpisodeToDelete(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to delete episode. Please try again.",
        variant: "destructive",
      });
      console.error("Error deleting episode:", error);
    }
  });

  const handleAnimeChange = (animeId: string) => {
    setSelectedAnime(Number(animeId));
    setCurrentPage(1);
  };

  const handleThumbnailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      form.setValue('thumbnailFile', file);
      const reader = new FileReader();
      reader.onload = () => {
        setThumbnailPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddButtonClick = () => {
    form.reset({
      anime_id: selectedAnime || 0,
      title: '',
      episode_number: 1,
      season_number: currentSeason,
      duration: '24:00',
      thumbnail: '',
      video_1080p: '',
      video_720p: '',
      video_480p: '',
      video_embed: '',
      description: '',
    });
    setThumbnailPreview(null);
    setIsAddDialogOpen(true);
  };

  const handleEditButtonClick = (episode: Episode) => {
    form.reset({
      anime_id: episode.anime_id,
      title: episode.title,
      episode_number: episode.episode_number,
      season_number: episode.season_number,
      duration: episode.duration,
      thumbnail: episode.thumbnail,
      video_1080p: episode.video_1080p || '',
      video_720p: episode.video_720p || '',
      video_480p: episode.video_480p || '',
      video_embed: episode.video_embed || '',
      description: episode.description || '',
    });
    setThumbnailPreview(episode.thumbnail);
    setEditEpisode(episode);
  };

  const confirmDelete = () => {
    if (episodeToDelete) {
      deleteEpisodeMutation.mutate(episodeToDelete.id);
    }
  };

  const onSubmit = (data: FormData) => {
    if (editEpisode) {
      updateEpisodeMutation.mutate({ ...data, id: editEpisode.id });
    } else {
      addEpisodeMutation.mutate(data);
    }
  };

  // Filter episodes by season and search term
  const filteredEpisodes = episodes
    ? episodes.filter((episode: Episode) => 
        episode.season_number === currentSeason &&
        episode.title.toLowerCase().includes(searchTerm.toLowerCase()))
    : [];

  // Sort episodes by episode number
  const sortedEpisodes = [...filteredEpisodes].sort((a: Episode, b: Episode) => 
    a.episode_number - b.episode_number
  );

  // Calculate pagination
  const totalPages = Math.ceil(sortedEpisodes.length / ITEMS_PER_PAGE);
  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
  const paginatedEpisodes = sortedEpisodes.slice(startIndex, startIndex + ITEMS_PER_PAGE);

  // Get seasons for the selected anime
  const seasons = episodes 
    ? [...new Set(episodes.map((ep: Episode) => ep.season_number))].sort((a, b) => a - b)
    : [1];

  // Get the current anime title
  const currentAnimeTitle = animes?.find((anime: Anime) => anime.id === selectedAnime)?.title || '';

  return (
    <>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
        <div className="w-full md:w-auto">
          <Select
            value={selectedAnime?.toString() || ''}
            onValueChange={handleAnimeChange}
          >
            <SelectTrigger className="bg-secondary text-text-primary w-full md:w-[300px]">
              <SelectValue placeholder="Select an anime" />
            </SelectTrigger>
            <SelectContent className="bg-surface text-text-primary border-secondary max-h-[400px]">
              {isLoadingAnimes ? (
                <div className="p-2">
                  <Skeleton className="h-6 w-full mb-2" />
                  <Skeleton className="h-6 w-full mb-2" />
                  <Skeleton className="h-6 w-full" />
                </div>
              ) : (
                animes?.map((anime: Anime) => (
                  <SelectItem key={anime.id} value={anime.id.toString()}>
                    {anime.title}
                  </SelectItem>
                ))
              )}
            </SelectContent>
          </Select>
        </div>
        
        <div className="flex flex-col md:flex-row gap-3 w-full md:w-auto">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary h-4 w-4" />
            <Input
              placeholder="Search episodes..."
              className="pl-9 bg-secondary text-text-primary w-full"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              disabled={!selectedAnime}
            />
          </div>
          
          <Button 
            className="bg-primary hover:bg-opacity-80 text-white"
            onClick={handleAddButtonClick}
            disabled={!selectedAnime}
          >
            <Plus className="mr-2 h-4 w-4" /> Add Episode
          </Button>
        </div>
      </div>

      {selectedAnime ? (
        <>
          <div className="mb-6">
            <Tabs 
              defaultValue={currentSeason.toString()} 
              onValueChange={(value) => setCurrentSeason(parseInt(value))}
              className="w-full"
            >
              <TabsList className="bg-secondary mb-4">
                {seasons.map(season => (
                  <TabsTrigger 
                    key={season} 
                    value={season.toString()}
                    className="data-[state=active]:bg-primary data-[state=active]:text-white"
                  >
                    Season {season}
                  </TabsTrigger>
                ))}
              </TabsList>
              
              {seasons.map(season => (
                <TabsContent key={season} value={season.toString()} className="mt-0">
                  <Card className="bg-surface shadow-lg border-none">
                    <CardContent className="p-0">
                      {isLoadingEpisodes ? (
                        <div className="p-6 space-y-4">
                          {[...Array(3)].map((_, index) => (
                            <div key={index} className="flex items-center">
                              <Skeleton className="h-12 w-full" />
                            </div>
                          ))}
                        </div>
                      ) : filteredEpisodes.length === 0 ? (
                        <div className="flex flex-col items-center justify-center py-12">
                          <PlayCircle className="h-16 w-16 text-text-secondary mb-4" />
                          <h3 className="text-xl font-medium">No Episodes Found</h3>
                          <p className="text-text-secondary mt-2">
                            {searchTerm ? 'Try a different search term' : `Add episodes to Season ${currentSeason} of "${currentAnimeTitle}"`}
                          </p>
                          {!searchTerm && (
                            <Button 
                              className="mt-4 bg-primary hover:bg-opacity-80 text-white"
                              onClick={handleAddButtonClick}
                            >
                              <Plus className="mr-2 h-4 w-4" /> Add Episode
                            </Button>
                          )}
                        </div>
                      ) : (
                        <>
                          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 p-4">
                            {paginatedEpisodes.map((episode: Episode) => (
                              <div 
                                key={episode.id} 
                                className="bg-secondary rounded-lg overflow-hidden flex flex-col sm:flex-row"
                              >
                                <div className="w-full sm:w-1/3 h-40 sm:h-auto relative">
                                  <img 
                                    src={episode.thumbnail} 
                                    alt={`Episode ${episode.episode_number}`} 
                                    className="w-full h-full object-cover"
                                    loading="lazy"
                                  />
                                </div>
                                <div className="p-4 flex-1">
                                  <div className="flex justify-between items-start mb-2">
                                    <div>
                                      <div className="flex items-center mb-1">
                                        <Badge className="bg-primary text-white mr-2">
                                          Ep {episode.episode_number}
                                        </Badge>
                                        <span className="text-text-secondary text-sm">
                                          {episode.duration}
                                        </span>
                                      </div>
                                      <h3 className="font-bold text-lg">{episode.title}</h3>
                                    </div>
                                    <div className="flex">
                                      <Button 
                                        variant="ghost" 
                                        size="icon"
                                        onClick={() => handleEditButtonClick(episode)}
                                      >
                                        <Edit className="h-4 w-4" />
                                      </Button>
                                      <AlertDialog open={episodeToDelete?.id === episode.id} onOpenChange={(open) => !open && setEpisodeToDelete(null)}>
                                        <AlertDialogTrigger asChild>
                                          <Button 
                                            variant="ghost" 
                                            size="icon"
                                            onClick={() => setEpisodeToDelete(episode)}
                                          >
                                            <Trash2 className="h-4 w-4 text-red-500" />
                                          </Button>
                                        </AlertDialogTrigger>
                                        <AlertDialogContent className="bg-surface text-text-primary border-secondary">
                                          <AlertDialogHeader>
                                            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                                            <AlertDialogDescription className="text-text-secondary">
                                              This will permanently delete Episode {episode.episode_number}: "{episode.title}".
                                              This action cannot be undone.
                                            </AlertDialogDescription>
                                          </AlertDialogHeader>
                                          <AlertDialogFooter>
                                            <AlertDialogCancel className="bg-secondary text-text-primary border-secondary">Cancel</AlertDialogCancel>
                                            <AlertDialogAction 
                                              onClick={confirmDelete}
                                              className="bg-red-600 hover:bg-red-700 text-white"
                                            >
                                              {deleteEpisodeMutation.isPending ? 'Deleting...' : 'Delete'}
                                            </AlertDialogAction>
                                          </AlertDialogFooter>
                                        </AlertDialogContent>
                                      </AlertDialog>
                                    </div>
                                  </div>
                                  <p className="text-text-secondary text-sm mb-3 line-clamp-2">
                                    {episode.description || 'No description available.'}
                                  </p>
                                  <div className="flex flex-wrap gap-2 mt-2">
                                    {episode.video_1080p && <Badge variant="outline">1080p</Badge>}
                                    {episode.video_720p && <Badge variant="outline">720p</Badge>}
                                    {episode.video_480p && <Badge variant="outline">480p</Badge>}
                                    {episode.video_embed && <Badge variant="outline">Embed</Badge>}
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                          
                          {/* Pagination */}
                          {totalPages > 1 && (
                            <div className="flex flex-col md:flex-row justify-between items-center p-4 border-t border-secondary space-y-2 md:space-y-0">
                              <div className="text-sm text-text-secondary text-center md:text-left">
                                Showing {startIndex + 1} to {Math.min(startIndex + ITEMS_PER_PAGE, filteredEpisodes.length)} of {filteredEpisodes.length} episodes
                              </div>
                              <div className="flex items-center space-x-2">
                                <Button 
                                  variant="outline" 
                                  size="icon" 
                                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                                  disabled={currentPage === 1}
                                  className="h-8 w-8"
                                >
                                  <ChevronLeft className="h-4 w-4" />
                                </Button>
                                <div className="text-sm">
                                  Page {currentPage} of {totalPages}
                                </div>
                                <Button 
                                  variant="outline" 
                                  size="icon" 
                                  onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                                  disabled={currentPage === totalPages}
                                  className="h-8 w-8"
                                >
                                  <ChevronRight className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                          )}
                        </>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>
              ))}
            </Tabs>
          </div>
          
          {/* Add/Edit Episode Dialog */}
          <Dialog 
            open={isAddDialogOpen || !!editEpisode} 
            onOpenChange={(open) => {
              if (!open) {
                setIsAddDialogOpen(false);
                setEditEpisode(null);
                form.reset();
                setThumbnailPreview(null);
              }
            }}
          >
            <DialogContent className="bg-surface text-text-primary border-secondary max-w-3xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editEpisode ? 'Edit Episode' : 'Add New Episode'}</DialogTitle>
              </DialogHeader>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="anime_id"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Anime</FormLabel>
                        <Select
                          onValueChange={(value) => field.onChange(parseInt(value))}
                          defaultValue={selectedAnime?.toString() || ''}
                          disabled={!!editEpisode}
                        >
                          <FormControl>
                            <SelectTrigger className="bg-secondary text-text-primary">
                              <SelectValue placeholder="Select anime" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent className="bg-surface text-text-primary border-secondary max-h-[400px]">
                            {animes?.map((anime: Anime) => (
                              <SelectItem key={anime.id} value={anime.id.toString()}>
                                {anime.title}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <FormField
                      control={form.control}
                      name="episode_number"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Episode Number</FormLabel>
                          <FormControl>
                            <Input 
                              type="number"
                              className="bg-secondary text-text-primary" 
                              {...field}
                              onChange={(e) => field.onChange(parseInt(e.target.value))} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="season_number"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Season Number</FormLabel>
                          <FormControl>
                            <Input 
                              type="number"
                              className="bg-secondary text-text-primary" 
                              {...field}
                              onChange={(e) => field.onChange(parseInt(e.target.value))} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="duration"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Duration (MM:SS)</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="24:00" 
                              className="bg-secondary text-text-primary" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Episode Title</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Enter episode title" 
                            className="bg-secondary text-text-primary" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Enter episode description" 
                            className="bg-secondary text-text-primary resize-none" 
                            rows={3} 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="thumbnailFile"
                      render={({ field: { value, onChange, ...field } }) => (
                        <FormItem>
                          <FormLabel>Thumbnail</FormLabel>
                          <FormControl>
                            <div className="border-2 border-dashed border-secondary rounded-lg p-4 text-center">
                              {thumbnailPreview ? (
                                <div className="mb-3 relative">
                                  <img src={thumbnailPreview} alt="Thumbnail Preview" className="max-h-40 mx-auto rounded-lg" />
                                  <Button 
                                    type="button"
                                    variant="destructive" 
                                    size="icon"
                                    className="absolute top-2 right-2 h-6 w-6"
                                    onClick={() => {
                                      setThumbnailPreview(null);
                                      form.setValue('thumbnailFile', undefined);
                                      form.setValue('thumbnail', '');
                                    }}
                                  >
                                    <X className="h-4 w-4" />
                                  </Button>
                                </div>
                              ) : (
                                <div className="mb-3">
                                  <Upload className="h-10 w-10 text-text-secondary mx-auto" />
                                </div>
                              )}
                              <p className="text-text-secondary text-sm mb-2">Drop your image here, or browse</p>
                              <Button
                                type="button"
                                variant="secondary"
                                onClick={() => document.getElementById('thumbnail-input')?.click()}
                                className="bg-secondary hover:bg-opacity-80 text-text-primary text-sm"
                              >
                                Choose File
                              </Button>
                              <input
                                id="thumbnail-input"
                                type="file"
                                accept="image/*"
                                className="hidden"
                                onChange={handleThumbnailChange}
                                {...field}
                              />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="space-y-6">
                      <FormField
                        control={form.control}
                        name="video_1080p"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>1080p Video URL</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Enter 1080p video URL" 
                                className="bg-secondary text-text-primary" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="video_720p"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>720p Video URL</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Enter 720p video URL" 
                                className="bg-secondary text-text-primary" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="video_480p"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>480p Video URL</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Enter 480p video URL" 
                              className="bg-secondary text-text-primary" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="video_embed"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Embed URL</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Enter embed URL" 
                              className="bg-secondary text-text-primary" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="flex justify-end">
                    <DialogClose asChild>
                      <Button
                        type="button"
                        variant="secondary"
                        className="mr-3"
                      >
                        Cancel
                      </Button>
                    </DialogClose>
                    <Button 
                      type="submit" 
                      className="bg-primary hover:bg-opacity-80 text-white"
                      disabled={addEpisodeMutation.isPending || updateEpisodeMutation.isPending}
                    >
                      {editEpisode 
                        ? (updateEpisodeMutation.isPending ? 'Updating...' : 'Update Episode')
                        : (addEpisodeMutation.isPending ? 'Adding...' : 'Add Episode')
                      }
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </>
      ) : (
        <Card className="bg-surface shadow-lg border-none">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <PlayCircle className="h-16 w-16 text-text-secondary mb-4" />
            <h3 className="text-xl font-medium">No Anime Selected</h3>
            <p className="text-text-secondary mt-2 text-center max-w-md">
              Please select an anime from the dropdown above to manage its episodes
            </p>
          </CardContent>
        </Card>
      )}
    </>
  );
};

export default EpisodeManagement;
