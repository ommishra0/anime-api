import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Link } from 'wouter';
import { 
  Edit, 
  Trash2, 
  Eye, 
  Search, 
  Plus, 
  Film,
  ArrowUpDown,
  ChevronLeft,
  ChevronRight 
} from 'lucide-react';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Anime } from '@shared/schema';

const ITEMS_PER_PAGE = 10;

const AnimeList = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [sortBy, setSortBy] = useState<string>('title');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [animeToDelete, setAnimeToDelete] = useState<Anime | null>(null);

  const { data: allAnimes, isLoading } = useQuery({
    queryKey: ['/api/animes'],
  });

  const deleteAnimeMutation = useMutation({
    mutationFn: (animeId: number) => {
      return apiRequest('DELETE', `/api/animes/${animeId}`, {});
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Anime deleted successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/animes'] });
      setAnimeToDelete(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to delete anime. Please try again.",
        variant: "destructive",
      });
      console.error("Error deleting anime:", error);
    }
  });

  const handleSort = (column: string) => {
    if (sortBy === column) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(column);
      setSortDirection('asc');
    }
  };

  const handleDeleteClick = (anime: Anime) => {
    setAnimeToDelete(anime);
  };

  const confirmDelete = () => {
    if (animeToDelete) {
      deleteAnimeMutation.mutate(animeToDelete.id);
    }
  };

  // Filter and sort anime list
  const filteredAnimes = allAnimes
    ? allAnimes.filter((anime: Anime) => 
        anime.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (anime.alternative_title && anime.alternative_title.toLowerCase().includes(searchTerm.toLowerCase())))
    : [];

  const sortedAnimes = [...filteredAnimes].sort((a: any, b: any) => {
    if (a[sortBy] < b[sortBy]) return sortDirection === 'asc' ? -1 : 1;
    if (a[sortBy] > b[sortBy]) return sortDirection === 'asc' ? 1 : -1;
    return 0;
  });

  // Calculate pagination
  const totalPages = Math.ceil(sortedAnimes.length / ITEMS_PER_PAGE);
  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
  const paginatedAnimes = sortedAnimes.slice(startIndex, startIndex + ITEMS_PER_PAGE);

  return (
    <>
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center space-x-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary h-4 w-4" />
            <Input
              placeholder="Search anime..."
              className="pl-9 bg-secondary text-text-primary w-[300px]"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        <Link href="/admin/add-anime">
          <Button className="bg-primary hover:bg-opacity-80 text-white">
            <Plus className="mr-2 h-4 w-4" /> Add New Anime
          </Button>
        </Link>
      </div>

      <Card className="bg-surface shadow-lg border-none">
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-4">
              {[...Array(5)].map((_, index) => (
                <div key={index} className="flex items-center">
                  <Skeleton className="h-12 w-full" />
                </div>
              ))}
            </div>
          ) : filteredAnimes.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12">
              <Film className="h-16 w-16 text-text-secondary mb-4" />
              <h3 className="text-xl font-medium">No Anime Found</h3>
              <p className="text-text-secondary mt-2">
                {searchTerm ? 'Try a different search term' : 'Add your first anime to get started'}
              </p>
              {!searchTerm && (
                <Link href="/admin/add-anime">
                  <Button className="mt-4 bg-primary hover:bg-opacity-80 text-white">
                    <Plus className="mr-2 h-4 w-4" /> Add Anime
                  </Button>
                </Link>
              )}
            </div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-12">ID</TableHead>
                      <TableHead>
                        <Button 
                          variant="ghost" 
                          className="p-0 font-semibold flex items-center"
                          onClick={() => handleSort('title')}
                        >
                          Title
                          <ArrowUpDown className="ml-1 h-4 w-4" />
                        </Button>
                      </TableHead>
                      <TableHead>
                        <Button 
                          variant="ghost" 
                          className="p-0 font-semibold flex items-center"
                          onClick={() => handleSort('type')}
                        >
                          Type
                          <ArrowUpDown className="ml-1 h-4 w-4" />
                        </Button>
                      </TableHead>
                      <TableHead>
                        <Button 
                          variant="ghost" 
                          className="p-0 font-semibold flex items-center"
                          onClick={() => handleSort('status')}
                        >
                          Status
                          <ArrowUpDown className="ml-1 h-4 w-4" />
                        </Button>
                      </TableHead>
                      <TableHead>
                        <Button 
                          variant="ghost" 
                          className="p-0 font-semibold flex items-center"
                          onClick={() => handleSort('release_year')}
                        >
                          Year
                          <ArrowUpDown className="ml-1 h-4 w-4" />
                        </Button>
                      </TableHead>
                      <TableHead>Tags</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paginatedAnimes.map((anime: Anime) => (
                      <TableRow key={anime.id}>
                        <TableCell>{anime.id}</TableCell>
                        <TableCell className="font-medium">{anime.title}</TableCell>
                        <TableCell>{anime.type}</TableCell>
                        <TableCell>
                          <Badge 
                            className={
                              anime.status === 'Airing' 
                                ? 'bg-green-600' 
                                : anime.status === 'Upcoming' 
                                  ? 'bg-blue-600' 
                                  : 'bg-slate-600'
                            }
                          >
                            {anime.status}
                          </Badge>
                        </TableCell>
                        <TableCell>{anime.release_year}</TableCell>
                        <TableCell>
                          <div className="flex flex-wrap gap-1">
                            {anime.featured && <Badge variant="secondary">Featured</Badge>}
                            {anime.trending && <Badge variant="secondary">Trending</Badge>}
                            {anime.top_rated && <Badge variant="secondary">Top Rated</Badge>}
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end space-x-2">
                            <Link href={`/anime/${anime.id}`}>
                              <Button variant="ghost" size="icon">
                                <Eye className="h-4 w-4" />
                              </Button>
                            </Link>
                            <Link href={`/admin/edit-anime/${anime.id}`}>
                              <Button variant="ghost" size="icon">
                                <Edit className="h-4 w-4" />
                              </Button>
                            </Link>
                            <AlertDialog open={animeToDelete?.id === anime.id} onOpenChange={(open) => !open && setAnimeToDelete(null)}>
                              <AlertDialogTrigger asChild>
                                <Button variant="ghost" size="icon" onClick={() => handleDeleteClick(anime)}>
                                  <Trash2 className="h-4 w-4 text-red-500" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent className="bg-surface text-text-primary border-secondary">
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                                  <AlertDialogDescription className="text-text-secondary">
                                    This will permanently delete "{anime.title}" and all associated episodes and data.
                                    This action cannot be undone.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel className="bg-secondary text-text-primary border-secondary">Cancel</AlertDialogCancel>
                                  <AlertDialogAction 
                                    onClick={confirmDelete}
                                    className="bg-red-600 hover:bg-red-700 text-white"
                                  >
                                    {deleteAnimeMutation.isPending ? 'Deleting...' : 'Delete'}
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              
              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex justify-between items-center p-4 border-t border-secondary">
                  <div className="text-sm text-text-secondary">
                    Showing {startIndex + 1} to {Math.min(startIndex + ITEMS_PER_PAGE, filteredAnimes.length)} of {filteredAnimes.length} anime
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button 
                      variant="outline" 
                      size="icon" 
                      onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                      disabled={currentPage === 1}
                      className="h-8 w-8"
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <div className="text-sm">
                      Page {currentPage} of {totalPages}
                    </div>
                    <Button 
                      variant="outline" 
                      size="icon" 
                      onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                      disabled={currentPage === totalPages}
                      className="h-8 w-8"
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>
    </>
  );
};

export default AnimeList;
