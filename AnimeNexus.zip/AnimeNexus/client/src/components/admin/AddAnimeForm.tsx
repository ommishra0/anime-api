import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Anime, insertAnimeSchema } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Upload, X, Plus } from 'lucide-react';
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { uploadFile } from '@/lib/supabase';

const formSchema = insertAnimeSchema.extend({
  coverImageFile: z.instanceof(File).optional(),
  bannerImageFile: z.instanceof(File).optional(),
  genres: z.string().array().min(1, "At least one genre is required")
});

type FormData = z.infer<typeof formSchema>;

const AddAnimeForm = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [coverImagePreview, setCoverImagePreview] = useState<string | null>(null);
  const [bannerImagePreview, setBannerImagePreview] = useState<string | null>(null);
  const [selectedGenres, setSelectedGenres] = useState<string[]>([]);
  const [genreInput, setGenreInput] = useState('');
  
  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: '',
      alternative_title: '',
      synopsis: '',
      type: 'TV',
      status: 'Airing',
      release_year: new Date().getFullYear(),
      rating: '0',
      genres: [],
      studios: '',
      director: '',
      cover_image: '',
      banner_image: '',
      featured: false,
      trending: false,
      top_rated: false,
    }
  });

  const addAnimeMutation = useMutation({
    mutationFn: async (data: FormData) => {
      // Handle file uploads
      let coverImageUrl = data.cover_image;
      let bannerImageUrl = data.banner_image;
      
      if (data.coverImageFile) {
        const fileName = `anime_covers/${Date.now()}_${data.coverImageFile.name}`;
        coverImageUrl = await uploadFile('anime-images', fileName, data.coverImageFile);
      }
      
      if (data.bannerImageFile) {
        const fileName = `anime_banners/${Date.now()}_${data.bannerImageFile.name}`;
        bannerImageUrl = await uploadFile('anime-images', fileName, data.bannerImageFile);
      }
      
      // Create anime with file URLs
      const animeData = {
        ...data,
        cover_image: coverImageUrl,
        banner_image: bannerImageUrl,
        genres: selectedGenres
      };
      
      // Remove file properties before sending to API
      delete animeData.coverImageFile;
      delete animeData.bannerImageFile;
      
      return apiRequest('POST', '/api/animes', animeData);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Anime added successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/animes'] });
      form.reset();
      setSelectedGenres([]);
      setCoverImagePreview(null);
      setBannerImagePreview(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to add anime. Please try again.",
        variant: "destructive",
      });
      console.error("Error adding anime:", error);
    }
  });

  const handleAddGenre = () => {
    if (genreInput.trim() && !selectedGenres.includes(genreInput.trim())) {
      const newGenres = [...selectedGenres, genreInput.trim()];
      setSelectedGenres(newGenres);
      form.setValue('genres', newGenres);
      setGenreInput('');
    }
  };

  const handleRemoveGenre = (genre: string) => {
    const newGenres = selectedGenres.filter(g => g !== genre);
    setSelectedGenres(newGenres);
    form.setValue('genres', newGenres);
  };

  const handleCoverImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      form.setValue('coverImageFile', file);
      const reader = new FileReader();
      reader.onload = () => {
        setCoverImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleBannerImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      form.setValue('bannerImageFile', file);
      const reader = new FileReader();
      reader.onload = () => {
        setBannerImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const onSubmit = (data: FormData) => {
    if (!data.coverImageFile && !data.cover_image) {
      toast({
        title: "Validation Error",
        description: "Please upload a cover image",
        variant: "destructive",
      });
      return;
    }
    
    if (!data.bannerImageFile && !data.banner_image) {
      toast({
        title: "Validation Error",
        description: "Please upload a banner image",
        variant: "destructive",
      });
      return;
    }
    
    addAnimeMutation.mutate(data);
  };

  return (
    <div className="bg-surface rounded-xl p-6 shadow-lg">
      <h2 className="text-lg font-bold font-inter mb-6">Add New Anime</h2>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Title</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Enter anime title" 
                      className="bg-secondary text-text-primary" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="alternative_title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Alternative Title</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Japanese or alternative title" 
                      className="bg-secondary text-text-primary" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          <FormField
            control={form.control}
            name="synopsis"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Synopsis</FormLabel>
                <FormControl>
                  <Textarea 
                    placeholder="Enter anime synopsis" 
                    className="bg-secondary text-text-primary resize-none" 
                    rows={4} 
                    {...field} 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Type</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger className="bg-secondary text-text-primary">
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent className="bg-secondary text-text-primary border-secondary">
                      <SelectItem value="TV">TV</SelectItem>
                      <SelectItem value="Movie">Movie</SelectItem>
                      <SelectItem value="OVA">OVA</SelectItem>
                      <SelectItem value="Special">Special</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Status</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger className="bg-secondary text-text-primary">
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent className="bg-secondary text-text-primary border-secondary">
                      <SelectItem value="Airing">Currently Airing</SelectItem>
                      <SelectItem value="Completed">Finished Airing</SelectItem>
                      <SelectItem value="Upcoming">Not Yet Aired</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="release_year"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Release Year</FormLabel>
                  <FormControl>
                    <Input 
                      type="number"
                      placeholder="2023" 
                      className="bg-secondary text-text-primary"
                      {...field}
                      onChange={(e) => field.onChange(parseInt(e.target.value))} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          <FormField
            control={form.control}
            name="genres"
            render={() => (
              <FormItem>
                <FormLabel>Genres</FormLabel>
                <div className="flex flex-wrap gap-2 p-3 bg-secondary rounded-lg">
                  {selectedGenres.map(genre => (
                    <div key={genre} className="bg-primary/20 text-primary rounded-full px-3 py-1 text-sm flex items-center">
                      {genre} 
                      <button type="button" className="ml-2" onClick={() => handleRemoveGenre(genre)}>
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  ))}
                  <div className="flex">
                    <Input 
                      type="text"
                      value={genreInput}
                      onChange={(e) => setGenreInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleAddGenre();
                        }
                      }}
                      className="bg-transparent border-0 focus:outline-none text-text-primary text-sm min-w-[100px] p-0 h-auto"
                      placeholder="Add genre..."
                    />
                    <Button 
                      type="button" 
                      variant="ghost" 
                      className="p-0 h-auto ml-1" 
                      onClick={handleAddGenre}
                    >
                      <Plus className="h-4 w-4 text-primary" />
                    </Button>
                  </div>
                </div>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="studios"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Studios</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="MAPPA, Ufotable, etc." 
                      className="bg-secondary text-text-primary" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="director"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Director</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Director name" 
                      className="bg-secondary text-text-primary" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="coverImageFile"
              render={({ field: { value, onChange, ...field } }) => (
                <FormItem>
                  <FormLabel>Cover Image</FormLabel>
                  <FormControl>
                    <div className="border-2 border-dashed border-secondary rounded-lg p-4 text-center">
                      {coverImagePreview ? (
                        <div className="mb-3 relative">
                          <img src={coverImagePreview} alt="Cover Preview" className="max-h-40 mx-auto rounded-lg" />
                          <Button 
                            type="button"
                            variant="destructive" 
                            size="icon"
                            className="absolute top-2 right-2 h-6 w-6"
                            onClick={() => {
                              setCoverImagePreview(null);
                              form.setValue('coverImageFile', undefined);
                            }}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ) : (
                        <div className="mb-3">
                          <Upload className="h-10 w-10 text-text-secondary mx-auto" />
                        </div>
                      )}
                      <p className="text-text-secondary text-sm mb-2">Drop your image here, or browse</p>
                      <Button
                        type="button"
                        variant="secondary"
                        onClick={() => document.getElementById('cover-image-input')?.click()}
                        className="bg-secondary hover:bg-opacity-80 text-text-primary text-sm"
                      >
                        Choose File
                      </Button>
                      <input
                        id="cover-image-input"
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={handleCoverImageChange}
                        {...field}
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="bannerImageFile"
              render={({ field: { value, onChange, ...field } }) => (
                <FormItem>
                  <FormLabel>Banner Image</FormLabel>
                  <FormControl>
                    <div className="border-2 border-dashed border-secondary rounded-lg p-4 text-center">
                      {bannerImagePreview ? (
                        <div className="mb-3 relative">
                          <img src={bannerImagePreview} alt="Banner Preview" className="max-h-40 mx-auto rounded-lg" />
                          <Button 
                            type="button"
                            variant="destructive" 
                            size="icon"
                            className="absolute top-2 right-2 h-6 w-6"
                            onClick={() => {
                              setBannerImagePreview(null);
                              form.setValue('bannerImageFile', undefined);
                            }}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ) : (
                        <div className="mb-3">
                          <Upload className="h-10 w-10 text-text-secondary mx-auto" />
                        </div>
                      )}
                      <p className="text-text-secondary text-sm mb-2">Drop your image here, or browse</p>
                      <Button
                        type="button"
                        variant="secondary"
                        onClick={() => document.getElementById('banner-image-input')?.click()}
                        className="bg-secondary hover:bg-opacity-80 text-text-primary text-sm"
                      >
                        Choose File
                      </Button>
                      <input
                        id="banner-image-input"
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={handleBannerImageChange}
                        {...field}
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          <div className="grid grid-cols-3 gap-6">
            <FormField
              control={form.control}
              name="featured"
              render={({ field }) => (
                <FormItem className="flex items-center space-x-2">
                  <FormControl>
                    <input
                      type="checkbox"
                      checked={field.value}
                      onChange={field.onChange}
                      className="w-4 h-4 accent-primary"
                    />
                  </FormControl>
                  <FormLabel className="m-0">Featured</FormLabel>
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="trending"
              render={({ field }) => (
                <FormItem className="flex items-center space-x-2">
                  <FormControl>
                    <input
                      type="checkbox"
                      checked={field.value}
                      onChange={field.onChange}
                      className="w-4 h-4 accent-primary"
                    />
                  </FormControl>
                  <FormLabel className="m-0">Trending</FormLabel>
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="top_rated"
              render={({ field }) => (
                <FormItem className="flex items-center space-x-2">
                  <FormControl>
                    <input
                      type="checkbox"
                      checked={field.value}
                      onChange={field.onChange}
                      className="w-4 h-4 accent-primary"
                    />
                  </FormControl>
                  <FormLabel className="m-0">Top Rated</FormLabel>
                </FormItem>
              )}
            />
          </div>
          
          <div className="flex justify-end">
            <Button
              type="button"
              variant="secondary"
              onClick={() => form.reset()}
              className="mr-3"
              disabled={addAnimeMutation.isPending}
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="bg-primary hover:bg-opacity-80 text-white"
              disabled={addAnimeMutation.isPending}
            >
              {addAnimeMutation.isPending ? 'Adding...' : 'Add Anime'}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
};

export default AddAnimeForm;
