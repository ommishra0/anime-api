import { Link } from 'wouter';
import { Facebook, Twitter, Instagram, MessageSquare } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-surface py-8">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between">
          <div className="mb-6 md:mb-0">
            <Link href="/" className="flex items-center">
              <span className="text-primary text-2xl font-bold font-montserrat">Anime<span className="text-accent">Stream</span></span>
            </Link>
            <p className="text-text-secondary mt-2 max-w-md">
              The ultimate destination for anime fans. Watch the latest episodes of your favorite anime shows in high quality.
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-text-primary font-bold mb-4">Browse</h3>
              <ul className="space-y-2">
                <li><Link href="/popular" className="text-text-secondary hover:text-primary transition-colors">Popular</Link></li>
                <li><Link href="/new-releases" className="text-text-secondary hover:text-primary transition-colors">New Releases</Link></li>
                <li><Link href="/genres" className="text-text-secondary hover:text-primary transition-colors">Genres</Link></li>
                <li><Link href="/simulcast" className="text-text-secondary hover:text-primary transition-colors">Simulcast</Link></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-text-primary font-bold mb-4">Company</h3>
              <ul className="space-y-2">
                <li><Link href="/about" className="text-text-secondary hover:text-primary transition-colors">About Us</Link></li>
                <li><Link href="/careers" className="text-text-secondary hover:text-primary transition-colors">Careers</Link></li>
                <li><Link href="/press" className="text-text-secondary hover:text-primary transition-colors">Press</Link></li>
                <li><Link href="/contact" className="text-text-secondary hover:text-primary transition-colors">Contact</Link></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-text-primary font-bold mb-4">Legal</h3>
              <ul className="space-y-2">
                <li><Link href="/terms" className="text-text-secondary hover:text-primary transition-colors">Terms of Service</Link></li>
                <li><Link href="/privacy" className="text-text-secondary hover:text-primary transition-colors">Privacy Policy</Link></li>
                <li><Link href="/cookies" className="text-text-secondary hover:text-primary transition-colors">Cookie Policy</Link></li>
                <li><Link href="/dmca" className="text-text-secondary hover:text-primary transition-colors">DMCA</Link></li>
              </ul>
            </div>
          </div>
        </div>
        
        <div className="mt-8 pt-8 border-t border-secondary flex flex-col md:flex-row justify-between items-center">
          <p className="text-text-secondary text-sm">&copy; {new Date().getFullYear()} AnimeStream. All rights reserved.</p>
          
          <div className="flex space-x-4 mt-4 md:mt-0">
            <a href="#" className="text-text-secondary hover:text-primary transition-colors text-xl">
              <Facebook size={20} />
            </a>
            <a href="#" className="text-text-secondary hover:text-primary transition-colors text-xl">
              <Twitter size={20} />
            </a>
            <a href="#" className="text-text-secondary hover:text-primary transition-colors text-xl">
              <Instagram size={20} />
            </a>
            <a href="#" className="text-text-secondary hover:text-primary transition-colors text-xl">
              <MessageSquare size={20} />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
