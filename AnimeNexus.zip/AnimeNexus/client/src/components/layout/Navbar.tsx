import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Search, Menu, X } from 'lucide-react';

const Navbar = () => {
  const [location, navigate] = useLocation();
  const { user, logout } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Implement search functionality
    console.log(`Searching for: ${searchQuery}`);
  };

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  return (
    <nav className="fixed top-0 w-full bg-surface shadow-md z-50">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <Link href="/" className="flex items-center">
              <span className="text-primary text-2xl font-bold font-montserrat">Anime<span className="text-accent">Stream</span></span>
            </Link>
            <div className="hidden md:flex space-x-6 ml-10">
              <Link href="/" className={`hover:text-primary transition-colors font-medium ${location === '/' ? 'text-primary' : 'text-text-secondary'}`}>
                Home
              </Link>
              <Link href="/browse" className={`hover:text-primary transition-colors font-medium ${location === '/browse' ? 'text-primary' : 'text-text-secondary'}`}>
                Browse
              </Link>
              <Link href="/simulcast" className={`hover:text-primary transition-colors font-medium ${location === '/simulcast' ? 'text-primary' : 'text-text-secondary'}`}>
                Simulcast
              </Link>
              <Link href="/manga" className={`hover:text-primary transition-colors font-medium ${location === '/manga' ? 'text-primary' : 'text-text-secondary'}`}>
                Manga
              </Link>
              <Link href="/news" className={`hover:text-primary transition-colors font-medium ${location === '/news' ? 'text-primary' : 'text-text-secondary'}`}>
                News
              </Link>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="relative hidden md:block">
              <form onSubmit={handleSearch}>
                <Input
                  type="text"
                  placeholder="Search anime..."
                  className="bg-secondary rounded-full py-2 px-4 pr-10 text-sm focus:outline-none focus:ring-2 focus:ring-primary text-text-primary w-64"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <Button 
                  type="submit" 
                  variant="ghost" 
                  size="icon" 
                  className="absolute right-1 top-1/2 transform -translate-y-1/2 text-text-secondary"
                >
                  <Search size={16} />
                </Button>
              </form>
            </div>
            
            {user ? (
              <div className="flex items-center space-x-2">
                {user.role === 'admin' && (
                  <Button 
                    variant="ghost" 
                    onClick={() => navigate('/admin')}
                    className="text-text-secondary hover:text-primary"
                  >
                    Admin
                  </Button>
                )}
                <Button 
                  variant="ghost" 
                  onClick={handleLogout}
                  className="text-text-secondary hover:text-primary"
                >
                  Logout
                </Button>
              </div>
            ) : (
              <Button 
                onClick={() => navigate('/login')}
                className="text-white bg-primary hover:bg-opacity-80 transition-colors"
              >
                Login
              </Button>
            )}
            
            <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden text-text-primary">
                  <Menu size={24} />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="bg-surface text-text-primary border-secondary">
                <div className="flex flex-col h-full">
                  <div className="flex items-center justify-between mb-6">
                    <span className="text-primary text-xl font-bold font-montserrat">Anime<span className="text-accent">Stream</span></span>
                    <Button variant="ghost" size="icon" onClick={() => setIsMobileMenuOpen(false)}>
                      <X size={24} />
                    </Button>
                  </div>
                  
                  <div className="mb-6">
                    <form onSubmit={handleSearch} className="relative">
                      <Input
                        type="text"
                        placeholder="Search anime..."
                        className="bg-secondary rounded-full py-2 px-4 pr-10 text-sm focus:outline-none focus:ring-2 focus:ring-primary text-text-primary w-full"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                      <Button 
                        type="submit" 
                        variant="ghost" 
                        size="icon" 
                        className="absolute right-1 top-1/2 transform -translate-y-1/2 text-text-secondary"
                      >
                        <Search size={16} />
                      </Button>
                    </form>
                  </div>
                  
                  <div className="flex flex-col space-y-4">
                    <Link href="/" className="text-text-primary hover:text-primary transition-colors font-medium py-2" onClick={() => setIsMobileMenuOpen(false)}>
                      Home
                    </Link>
                    <Link href="/browse" className="text-text-secondary hover:text-primary transition-colors font-medium py-2" onClick={() => setIsMobileMenuOpen(false)}>
                      Browse
                    </Link>
                    <Link href="/simulcast" className="text-text-secondary hover:text-primary transition-colors font-medium py-2" onClick={() => setIsMobileMenuOpen(false)}>
                      Simulcast
                    </Link>
                    <Link href="/manga" className="text-text-secondary hover:text-primary transition-colors font-medium py-2" onClick={() => setIsMobileMenuOpen(false)}>
                      Manga
                    </Link>
                    <Link href="/news" className="text-text-secondary hover:text-primary transition-colors font-medium py-2" onClick={() => setIsMobileMenuOpen(false)}>
                      News
                    </Link>
                  </div>
                  
                  <div className="mt-auto pt-4 border-t border-secondary">
                    {user ? (
                      <div className="flex flex-col space-y-2">
                        {user.role === 'admin' && (
                          <Link href="/admin" className="w-full">
                            <Button 
                              variant="secondary" 
                              className="w-full" 
                              onClick={() => setIsMobileMenuOpen(false)}
                            >
                              Admin Panel
                            </Button>
                          </Link>
                        )}
                        <Button 
                          variant="outline" 
                          onClick={() => {
                            handleLogout();
                            setIsMobileMenuOpen(false);
                          }}
                          className="w-full"
                        >
                          Logout
                        </Button>
                      </div>
                    ) : (
                      <Link href="/login" className="w-full">
                        <Button 
                          className="w-full bg-primary hover:bg-opacity-80 transition-colors"
                          onClick={() => setIsMobileMenuOpen(false)}
                        >
                          Login
                        </Button>
                      </Link>
                    )}
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
