import fetch from 'node-fetch';
import { Anime, InsertAnime } from '@shared/schema';

const TMDB_API_KEY = process.env.TMDB_API_KEY;
const TMDB_BASE_URL = 'https://api.themoviedb.org/3';

/**
 * TMDB API Scraper utility to fetch anime information
 */
export class TMDBScraper {
  private apiKey: string;
  
  constructor(apiKey: string = TMDB_API_KEY || '') {
    this.apiKey = apiKey;
  }
  
  /**
   * Search for anime on TMDB
   */
  async searchAnime(query: string): Promise<any[]> {
    try {
      const url = `${TMDB_BASE_URL}/search/tv?api_key=${this.apiKey}&query=${encodeURIComponent(query)}&language=en-US&page=1`;
      const response = await fetch(url);
      const data = await response.json() as any;
      
      // Filter results for anime (look for animation genre or anime keywords)
      const results = data.results.filter((result: any) => {
        // Filter based on known anime-related genre IDs
        // 16 = Animation
        return result.genre_ids?.includes(16);
      });
      
      return results;
    } catch (error) {
      console.error('Error searching TMDB for anime:', error);
      return [];
    }
  }
  
  /**
   * Get detailed information about an anime by TMDB ID
   */
  async getAnimeDetails(tmdbId: number): Promise<any> {
    try {
      // Get main TV show details
      const url = `${TMDB_BASE_URL}/tv/${tmdbId}?api_key=${this.apiKey}&language=en-US&append_to_response=credits,external_ids,keywords,similar,images,content_ratings`;
      const response = await fetch(url);
      const data = await response.json() as any;
      
      return data;
    } catch (error) {
      console.error(`Error fetching anime details for ID ${tmdbId}:`, error);
      return null;
    }
  }
  
  /**
   * Get voice actor information for an anime
   */
  async getAnimeVoiceActors(tmdbId: number): Promise<string[]> {
    try {
      const data = await this.getAnimeDetails(tmdbId);
      
      if (!data || !data.credits) {
        return [];
      }
      
      // Get voice actors from the cast (people with "Voice" in their role)
      const voiceActors = data.credits.cast
        .filter((castMember: any) => 
          castMember.known_for_department === "Acting" && 
          castMember.character?.toLowerCase().includes('voice')
        )
        .map((actor: any) => actor.name);
      
      return voiceActors;
    } catch (error) {
      console.error(`Error fetching voice actors for ID ${tmdbId}:`, error);
      return [];
    }
  }
  
  /**
   * Get the number of episodes for an anime
   */
  async getAnimeEpisodeCount(tmdbId: number): Promise<number> {
    try {
      const data = await this.getAnimeDetails(tmdbId);
      
      if (!data) {
        return 0;
      }
      
      let totalEpisodes = 0;
      
      // Get episode count from seasons
      if (data.seasons) {
        for (const season of data.seasons) {
          if (season.season_number > 0) { // Skip specials (season 0)
            totalEpisodes += season.episode_count || 0;
          }
        }
      }
      
      return totalEpisodes;
    } catch (error) {
      console.error(`Error fetching episode count for ID ${tmdbId}:`, error);
      return 0;
    }
  }
  
  /**
   * Get high quality images for an anime
   */
  async getAnimeImages(tmdbId: number): Promise<{cover_image: string, banner_image: string}> {
    try {
      const data = await this.getAnimeDetails(tmdbId);
      
      if (!data) {
        return {
          cover_image: '',
          banner_image: ''
        };
      }
      
      // Base URL for images
      const baseUrl = 'https://image.tmdb.org/t/p/';
      
      // Get poster (cover image) - use high resolution
      const posterPath = data.poster_path;
      const coverImage = posterPath ? `${baseUrl}w780${posterPath}` : '';
      
      // Get backdrop (banner image) - use high resolution
      const backdropPath = data.backdrop_path;
      const bannerImage = backdropPath ? `${baseUrl}original${backdropPath}` : '';
      
      return {
        cover_image: coverImage,
        banner_image: bannerImage
      };
    } catch (error) {
      console.error(`Error fetching images for ID ${tmdbId}:`, error);
      return {
        cover_image: '',
        banner_image: ''
      };
    }
  }
  
  /**
   * Convert TMDB anime data to our anime schema format
   */
  async convertToAnimeSchema(tmdbId: number): Promise<Partial<InsertAnime>> {
    try {
      const data = await this.getAnimeDetails(tmdbId);
      
      if (!data) {
        throw new Error(`No data found for TMDB ID ${tmdbId}`);
      }
      
      // Get images
      const images = await this.getAnimeImages(tmdbId);
      
      // Get voice actors
      const voiceActors = await this.getAnimeVoiceActors(tmdbId);
      
      // Get episode count
      const episodesCount = await this.getAnimeEpisodeCount(tmdbId);
      
      // Convert TMDB genres to string array
      const genres = data.genres?.map((genre: any) => genre.name) || [];
      
      // Format release year
      const releaseYear = data.first_air_date 
        ? parseInt(data.first_air_date.split('-')[0]) 
        : 0;
      
      // Determine status
      let status = 'unknown';
      if (data.status) {
        if (data.status === 'Ended') status = 'completed';
        else if (data.status === 'Returning Series') status = 'ongoing';
        else if (data.status === 'Canceled') status = 'completed';
        else status = data.status.toLowerCase();
      }
      
      // Create the anime object with our schema format
      const anime: Partial<InsertAnime> = {
        title: data.name,
        alternative_title: data.original_name !== data.name ? data.original_name : null,
        synopsis: data.overview || '',
        type: 'TV',
        status,
        release_year: releaseYear,
        rating: data.vote_average ? data.vote_average.toString() : null,
        genres,
        studios: data.networks?.map((network: any) => network.name).join(', ') || null,
        director: null, // TMDB doesn't provide director info easily
        cover_image: images.cover_image || '',
        banner_image: images.banner_image || '',
        episodes_count: episodesCount,
        tmdb_id: tmdbId,
        voice_actors: voiceActors.length > 0 ? voiceActors : null,
        featured: false,
        trending: data.popularity > 50, // Arbitrary threshold
        top_rated: data.vote_average >= 8.0, // Arbitrary threshold
      };
      
      return anime;
    } catch (error) {
      console.error(`Error converting TMDB data to anime schema for ID ${tmdbId}:`, error);
      throw error;
    }
  }
}

// Export singleton instance
export const tmdbScraper = new TMDBScraper();