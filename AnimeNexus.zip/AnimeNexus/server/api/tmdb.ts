import { Router, Request, Response } from 'express';
import { tmdbScraper } from '../utils/tmdbScraper';
import { storage } from '../storage';
import { z } from 'zod';
import { log } from '../vite';

// Session types
interface RequestWithSession extends Request {
  session: {
    user?: {
      id: number;
      email: string;
      username: string;
      role: string;
      avatar_url?: string;
    };
  };
}

const router = Router();

// Search for anime on TMDB
router.get('/search', async (req, res) => {
  try {
    const query = req.query.q as string;
    
    if (!query || query.trim().length === 0) {
      return res.status(400).json({ error: 'Search query is required' });
    }
    
    const results = await tmdbScraper.searchAnime(query);
    res.json(results);
  } catch (error) {
    log(`Error searching TMDB: ${error}`, 'tmdb-api');
    res.status(500).json({ error: 'Failed to search TMDB' });
  }
});

// Get anime details from TMDB
router.get('/details/:id', async (req, res) => {
  try {
    const tmdbId = parseInt(req.params.id);
    
    if (isNaN(tmdbId)) {
      return res.status(400).json({ error: 'Invalid TMDB ID' });
    }
    
    const details = await tmdbScraper.getAnimeDetails(tmdbId);
    
    if (!details) {
      return res.status(404).json({ error: 'Anime not found on TMDB' });
    }
    
    res.json(details);
  } catch (error) {
    log(`Error fetching TMDB details: ${error}`, 'tmdb-api');
    res.status(500).json({ error: 'Failed to fetch TMDB details' });
  }
});

// Get voice actors for an anime from TMDB
router.get('/voice-actors/:id', async (req, res) => {
  try {
    const tmdbId = parseInt(req.params.id);
    
    if (isNaN(tmdbId)) {
      return res.status(400).json({ error: 'Invalid TMDB ID' });
    }
    
    const voiceActors = await tmdbScraper.getAnimeVoiceActors(tmdbId);
    res.json(voiceActors);
  } catch (error) {
    log(`Error fetching voice actors: ${error}`, 'tmdb-api');
    res.status(500).json({ error: 'Failed to fetch voice actors' });
  }
});

// Get episode count for an anime from TMDB
router.get('/episode-count/:id', async (req, res) => {
  try {
    const tmdbId = parseInt(req.params.id);
    
    if (isNaN(tmdbId)) {
      return res.status(400).json({ error: 'Invalid TMDB ID' });
    }
    
    const episodeCount = await tmdbScraper.getAnimeEpisodeCount(tmdbId);
    res.json({ episodeCount });
  } catch (error) {
    log(`Error fetching episode count: ${error}`, 'tmdb-api');
    res.status(500).json({ error: 'Failed to fetch episode count' });
  }
});

// Get images for an anime from TMDB
router.get('/images/:id', async (req, res) => {
  try {
    const tmdbId = parseInt(req.params.id);
    
    if (isNaN(tmdbId)) {
      return res.status(400).json({ error: 'Invalid TMDB ID' });
    }
    
    const images = await tmdbScraper.getAnimeImages(tmdbId);
    res.json(images);
  } catch (error) {
    log(`Error fetching images: ${error}`, 'tmdb-api');
    res.status(500).json({ error: 'Failed to fetch images' });
  }
});

// Convert TMDB data to our anime schema and return
router.get('/convert/:id', async (req, res) => {
  try {
    const tmdbId = parseInt(req.params.id);
    
    if (isNaN(tmdbId)) {
      return res.status(400).json({ error: 'Invalid TMDB ID' });
    }
    
    const animeData = await tmdbScraper.convertToAnimeSchema(tmdbId);
    res.json(animeData);
  } catch (error) {
    log(`Error converting TMDB data: ${error}`, 'tmdb-api');
    res.status(500).json({ error: 'Failed to convert TMDB data' });
  }
});

// Import an anime from TMDB directly into our database
router.post('/import', async (req: RequestWithSession, res: Response) => {
  try {
    // Make sure user is authenticated and is an admin
    if (!req.session || !req.session.user || req.session.user.role !== 'admin') {
      return res.status(403).json({ error: 'Unauthorized' });
    }
    
    const importSchema = z.object({
      tmdbId: z.number().int().positive(),
    });
    
    const validationResult = importSchema.safeParse(req.body);
    
    if (!validationResult.success) {
      return res.status(400).json({ 
        error: 'Invalid request data',
        details: validationResult.error.errors 
      });
    }
    
    const { tmdbId } = validationResult.data;
    
    // Get the anime data from TMDB
    const animeData = await tmdbScraper.convertToAnimeSchema(tmdbId);
    
    // Save to database
    const savedAnime = await storage.createAnime(animeData);
    
    res.json({ 
      success: true, 
      message: 'Anime imported successfully',
      data: savedAnime
    });
  } catch (error) {
    log(`Error importing from TMDB: ${error}`, 'tmdb-api');
    res.status(500).json({ error: 'Failed to import from TMDB' });
  }
});

export default router;