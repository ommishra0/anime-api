import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { 
  insertUserSchema, 
  insertAnimeSchema, 
  insertEpisodeSchema, 
  insertReviewSchema,
  insertCommentSchema 
} from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import bcrypt from "bcryptjs";
import tmdbRoutes from "./api/tmdb";

// Session types
interface SessionUser {
  id: number;
  email: string;
  username: string;
  role: string;
  avatar_url?: string;
}

declare module "express-session" {
  interface SessionData {
    user?: SessionUser;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication middleware
  const ensureAuthenticated = (req: any, res: any, next: any) => {
    if (req.session && req.session.user) {
      return next();
    }
    res.status(401).json({ message: "Unauthorized" });
  };

  // Admin middleware
  const ensureAdmin = (req: any, res: any, next: any) => {
    if (req.session && req.session.user && req.session.user.role === "admin") {
      return next();
    }
    res.status(403).json({ message: "Forbidden: Admin access required" });
  };

  // Helper function to handle validation
  const validateBody = (schema: z.ZodType<any>) => {
    return (req: any, res: any, next: any) => {
      try {
        req.validatedBody = schema.parse(req.body);
        next();
      } catch (error) {
        if (error instanceof ZodError) {
          const validationError = fromZodError(error);
          res.status(400).json({ message: validationError.message });
        } else {
          res.status(400).json({ message: "Invalid request body" });
        }
      }
    };
  };

  // AUTH ROUTES
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ message: "Email and password are required" });
      }
      
      const user = await storage.getUserByEmail(email);
      
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      const isPasswordValid = await bcrypt.compare(password, user.password);
      
      if (!isPasswordValid) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // Set user in session (without password)
      const { password: _, ...userWithoutPassword } = user;
      req.session.user = userWithoutPassword;
      
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ message: "Server error during login" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Failed to logout" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/auth/session", (req, res) => {
    if (req.session && req.session.user) {
      res.json(req.session.user);
    } else {
      res.status(401).json({ message: "Not authenticated" });
    }
  });

  // USER ROUTES
  app.get("/api/users", ensureAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      // Remove passwords from response
      const usersWithoutPasswords = users.map(({ password, ...user }) => user);
      res.json(usersWithoutPasswords);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.get("/api/users/:id", ensureAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Only admin or the user themselves can access user details
      if (req.session.user!.role !== "admin" && req.session.user!.id !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // ANIME ROUTES
  app.get("/api/animes", async (req, res) => {
    try {
      const animes = await storage.getAllAnimes();
      res.json(animes);
    } catch (error) {
      console.error("Error fetching animes:", error);
      res.status(500).json({ message: "Failed to fetch animes" });
    }
  });

  app.get("/api/animes/featured", async (req, res) => {
    try {
      const featuredAnimes = await storage.getFeaturedAnimes();
      res.json(featuredAnimes);
    } catch (error) {
      console.error("Error fetching featured animes:", error);
      res.status(500).json({ message: "Failed to fetch featured animes" });
    }
  });

  app.get("/api/animes/trending", async (req, res) => {
    try {
      const trendingAnimes = await storage.getTrendingAnimes();
      res.json(trendingAnimes);
    } catch (error) {
      console.error("Error fetching trending animes:", error);
      res.status(500).json({ message: "Failed to fetch trending animes" });
    }
  });

  app.get("/api/animes/recent", async (req, res) => {
    try {
      const recentAnimes = await storage.getRecentAnimes();
      res.json(recentAnimes);
    } catch (error) {
      console.error("Error fetching recent animes:", error);
      res.status(500).json({ message: "Failed to fetch recent animes" });
    }
  });

  app.get("/api/animes/top-rated", async (req, res) => {
    try {
      const topRatedAnimes = await storage.getTopRatedAnimes();
      res.json(topRatedAnimes);
    } catch (error) {
      console.error("Error fetching top-rated animes:", error);
      res.status(500).json({ message: "Failed to fetch top-rated animes" });
    }
  });

  app.get("/api/animes/:id", async (req, res) => {
    try {
      const animeId = parseInt(req.params.id);
      const anime = await storage.getAnime(animeId);
      
      if (!anime) {
        return res.status(404).json({ message: "Anime not found" });
      }
      
      res.json(anime);
    } catch (error) {
      console.error("Error fetching anime:", error);
      res.status(500).json({ message: "Failed to fetch anime" });
    }
  });

  app.post("/api/animes", ensureAdmin, validateBody(insertAnimeSchema), async (req, res) => {
    try {
      const animeData = req.validatedBody;
      const newAnime = await storage.createAnime(animeData);
      res.status(201).json(newAnime);
    } catch (error) {
      console.error("Error creating anime:", error);
      res.status(500).json({ message: "Failed to create anime" });
    }
  });

  app.put("/api/animes/:id", ensureAdmin, validateBody(insertAnimeSchema), async (req, res) => {
    try {
      const animeId = parseInt(req.params.id);
      const animeData = req.validatedBody;
      const updatedAnime = await storage.updateAnime(animeId, animeData);
      
      if (!updatedAnime) {
        return res.status(404).json({ message: "Anime not found" });
      }
      
      res.json(updatedAnime);
    } catch (error) {
      console.error("Error updating anime:", error);
      res.status(500).json({ message: "Failed to update anime" });
    }
  });

  app.delete("/api/animes/:id", ensureAdmin, async (req, res) => {
    try {
      const animeId = parseInt(req.params.id);
      const success = await storage.deleteAnime(animeId);
      
      if (!success) {
        return res.status(404).json({ message: "Anime not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting anime:", error);
      res.status(500).json({ message: "Failed to delete anime" });
    }
  });

  // EPISODE ROUTES
  app.get("/api/episodes", async (req, res) => {
    try {
      const episodes = await storage.getAllEpisodes();
      res.json(episodes);
    } catch (error) {
      console.error("Error fetching episodes:", error);
      res.status(500).json({ message: "Failed to fetch episodes" });
    }
  });

  app.get("/api/animes/:animeId/episodes", async (req, res) => {
    try {
      const animeId = parseInt(req.params.animeId);
      const episodes = await storage.getEpisodesByAnime(animeId);
      res.json(episodes);
    } catch (error) {
      console.error("Error fetching episodes by anime:", error);
      res.status(500).json({ message: "Failed to fetch episodes" });
    }
  });

  app.get("/api/episodes/:id", async (req, res) => {
    try {
      const episodeId = parseInt(req.params.id);
      const episode = await storage.getEpisode(episodeId);
      
      if (!episode) {
        return res.status(404).json({ message: "Episode not found" });
      }
      
      res.json(episode);
    } catch (error) {
      console.error("Error fetching episode:", error);
      res.status(500).json({ message: "Failed to fetch episode" });
    }
  });

  app.post("/api/episodes", ensureAdmin, validateBody(insertEpisodeSchema), async (req, res) => {
    try {
      const episodeData = req.validatedBody;
      const newEpisode = await storage.createEpisode(episodeData);
      res.status(201).json(newEpisode);
    } catch (error) {
      console.error("Error creating episode:", error);
      res.status(500).json({ message: "Failed to create episode" });
    }
  });

  app.put("/api/episodes/:id", ensureAdmin, validateBody(insertEpisodeSchema), async (req, res) => {
    try {
      const episodeId = parseInt(req.params.id);
      const episodeData = req.validatedBody;
      const updatedEpisode = await storage.updateEpisode(episodeId, episodeData);
      
      if (!updatedEpisode) {
        return res.status(404).json({ message: "Episode not found" });
      }
      
      res.json(updatedEpisode);
    } catch (error) {
      console.error("Error updating episode:", error);
      res.status(500).json({ message: "Failed to update episode" });
    }
  });

  app.delete("/api/episodes/:id", ensureAdmin, async (req, res) => {
    try {
      const episodeId = parseInt(req.params.id);
      const success = await storage.deleteEpisode(episodeId);
      
      if (!success) {
        return res.status(404).json({ message: "Episode not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting episode:", error);
      res.status(500).json({ message: "Failed to delete episode" });
    }
  });

  // REVIEW ROUTES
  app.get("/api/animes/:animeId/reviews", async (req, res) => {
    try {
      const animeId = parseInt(req.params.animeId);
      const reviews = await storage.getReviewsByAnime(animeId);
      res.json(reviews);
    } catch (error) {
      console.error("Error fetching reviews by anime:", error);
      res.status(500).json({ message: "Failed to fetch reviews" });
    }
  });

  app.post("/api/reviews", ensureAuthenticated, validateBody(insertReviewSchema), async (req, res) => {
    try {
      const reviewData = req.validatedBody;
      
      // Ensure the user can only create reviews as themselves
      if (reviewData.user_id !== req.session.user!.id && req.session.user!.role !== "admin") {
        return res.status(403).json({ message: "You can only create reviews as yourself" });
      }
      
      const newReview = await storage.createReview(reviewData);
      res.status(201).json(newReview);
    } catch (error) {
      console.error("Error creating review:", error);
      res.status(500).json({ message: "Failed to create review" });
    }
  });

  app.delete("/api/reviews/:id", ensureAuthenticated, async (req, res) => {
    try {
      const reviewId = parseInt(req.params.id);
      const review = await storage.getReview(reviewId);
      
      if (!review) {
        return res.status(404).json({ message: "Review not found" });
      }
      
      // Only the author or admin can delete the review
      if (review.user_id !== req.session.user!.id && req.session.user!.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const success = await storage.deleteReview(reviewId);
      
      if (!success) {
        return res.status(404).json({ message: "Review not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting review:", error);
      res.status(500).json({ message: "Failed to delete review" });
    }
  });

  // COMMENT ROUTES
  app.get("/api/episodes/:episodeId/comments", async (req, res) => {
    try {
      const episodeId = parseInt(req.params.episodeId);
      const comments = await storage.getCommentsByEpisode(episodeId);
      res.json(comments);
    } catch (error) {
      console.error("Error fetching comments by episode:", error);
      res.status(500).json({ message: "Failed to fetch comments" });
    }
  });

  app.post("/api/comments", ensureAuthenticated, validateBody(insertCommentSchema), async (req, res) => {
    try {
      const commentData = req.validatedBody;
      
      // Ensure the user can only create comments as themselves
      if (commentData.user_id !== req.session.user!.id && req.session.user!.role !== "admin") {
        return res.status(403).json({ message: "You can only create comments as yourself" });
      }
      
      const newComment = await storage.createComment(commentData);
      res.status(201).json(newComment);
    } catch (error) {
      console.error("Error creating comment:", error);
      res.status(500).json({ message: "Failed to create comment" });
    }
  });

  app.post("/api/comments/:id/vote", ensureAuthenticated, async (req, res) => {
    try {
      const commentId = parseInt(req.params.id);
      const { is_like } = req.body;
      
      if (typeof is_like !== 'boolean') {
        return res.status(400).json({ message: "is_like must be a boolean" });
      }
      
      const comment = await storage.getComment(commentId);
      
      if (!comment) {
        return res.status(404).json({ message: "Comment not found" });
      }
      
      const updatedComment = await storage.voteComment(commentId, is_like);
      res.json(updatedComment);
    } catch (error) {
      console.error("Error voting on comment:", error);
      res.status(500).json({ message: "Failed to vote on comment" });
    }
  });

  app.delete("/api/comments/:id", ensureAuthenticated, async (req, res) => {
    try {
      const commentId = parseInt(req.params.id);
      const comment = await storage.getComment(commentId);
      
      if (!comment) {
        return res.status(404).json({ message: "Comment not found" });
      }
      
      // Only the author or admin can delete the comment
      if (comment.user_id !== req.session.user!.id && req.session.user!.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const success = await storage.deleteComment(commentId);
      
      if (!success) {
        return res.status(404).json({ message: "Comment not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting comment:", error);
      res.status(500).json({ message: "Failed to delete comment" });
    }
  });

  // ADMIN DASHBOARD ROUTES
  app.get("/api/admin/stats", ensureAdmin, async (req, res) => {
    try {
      const animes = await storage.getAllAnimes();
      const episodes = await storage.getAllEpisodes();
      const users = await storage.getAllUsers();
      
      // Calculate changes (for demo purposes just random percentages)
      const animeChange = Math.floor(Math.random() * 20) + 1;
      const episodeChange = Math.floor(Math.random() * 15) + 1;
      const userChange = Math.floor(Math.random() * 25) + 1;
      
      res.json({
        animeCount: animes.length,
        episodeCount: episodes.length,
        userCount: users.length,
        animeChange,
        episodeChange,
        userChange,
        storageUsed: "4.2",
        storagePercentage: 75
      });
    } catch (error) {
      console.error("Error fetching admin stats:", error);
      res.status(500).json({ message: "Failed to fetch admin stats" });
    }
  });

  app.get("/api/admin/recent-uploads", ensureAdmin, async (req, res) => {
    try {
      const recentEpisodes = await storage.getRecentEpisodes(5);
      
      const recentUploads = await Promise.all(
        recentEpisodes.map(async (episode) => {
          const anime = await storage.getAnime(episode.anime_id);
          return {
            ...episode,
            anime_title: anime ? anime.title : "Unknown Anime"
          };
        })
      );
      
      res.json(recentUploads);
    } catch (error) {
      console.error("Error fetching recent uploads:", error);
      res.status(500).json({ message: "Failed to fetch recent uploads" });
    }
  });

  app.get("/api/admin/user-activities", ensureAdmin, async (req, res) => {
    try {
      // For demo purposes, creating some mock recent activities
      const users = await storage.getAllUsers();
      const activities = [];
      
      if (users.length > 0) {
        const actions = [
          "Added a review",
          "Reported a comment",
          "New account created",
          "Subscription renewed"
        ];
        
        const times = [
          "1 hour ago",
          "3 hours ago",
          "6 hours ago",
          "8 hours ago"
        ];
        
        for (let i = 0; i < Math.min(4, users.length); i++) {
          activities.push({
            id: i + 1,
            username: users[i].username,
            action: actions[i],
            timestamp: new Date(Date.now() - (i + 1) * 3600000).toISOString()
          });
        }
      }
      
      res.json(activities);
    } catch (error) {
      console.error("Error fetching user activities:", error);
      res.status(500).json({ message: "Failed to fetch user activities" });
    }
  });

  // Register TMDB API routes
  app.use("/api/tmdb", tmdbRoutes);

  const httpServer = createServer(app);

  return httpServer;
}
