import { 
  users, User, InsertUser,
  animes, Anime, InsertAnime, 
  episodes, Episode, InsertEpisode,
  reviews, Review, InsertReview,
  comments, Comment, InsertComment
} from "@shared/schema";
import bcrypt from "bcryptjs";

// Storage interface defining all DB operations
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // Session store
  sessionStore: session.Store;
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;

  // Anime operations
  getAnime(id: number): Promise<Anime | undefined>;
  getAllAnimes(): Promise<Anime[]>;
  getFeaturedAnimes(limit?: number): Promise<Anime[]>;
  getTrendingAnimes(limit?: number): Promise<Anime[]>;
  getRecentAnimes(limit?: number): Promise<Anime[]>;
  getTopRatedAnimes(limit?: number): Promise<Anime[]>;
  createAnime(anime: InsertAnime): Promise<Anime>;
  updateAnime(id: number, anime: InsertAnime): Promise<Anime | undefined>;
  deleteAnime(id: number): Promise<boolean>;

  // Episode operations
  getEpisode(id: number): Promise<Episode | undefined>;
  getAllEpisodes(): Promise<Episode[]>;
  getEpisodesByAnime(animeId: number): Promise<Episode[]>;
  getRecentEpisodes(limit?: number): Promise<Episode[]>;
  createEpisode(episode: InsertEpisode): Promise<Episode>;
  updateEpisode(id: number, episode: InsertEpisode): Promise<Episode | undefined>;
  deleteEpisode(id: number): Promise<boolean>;

  // Review operations
  getReview(id: number): Promise<Review | undefined>;
  getReviewsByAnime(animeId: number): Promise<(Review & { user: User })[]>;
  createReview(review: InsertReview): Promise<Review>;
  deleteReview(id: number): Promise<boolean>;

  // Comment operations
  getComment(id: number): Promise<Comment | undefined>;
  getCommentsByEpisode(episodeId: number): Promise<(Comment & { user: User; replies?: (Comment & { user: User })[] })[]>;
  createComment(comment: InsertComment): Promise<Comment>;
  voteComment(id: number, isLike: boolean): Promise<Comment | undefined>;
  deleteComment(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private usersMap: Map<number, User>;
  private animesMap: Map<number, Anime>;
  private episodesMap: Map<number, Episode>;
  private reviewsMap: Map<number, Review>;
  private commentsMap: Map<number, Comment>;
  
  private currentUserId: number;
  private currentAnimeId: number;
  private currentEpisodeId: number;
  private currentReviewId: number;
  private currentCommentId: number;

  sessionStore: session.Store;

  constructor() {
    this.usersMap = new Map();
    this.animesMap = new Map();
    this.episodesMap = new Map();
    this.reviewsMap = new Map();
    this.commentsMap = new Map();
    
    this.currentUserId = 1;
    this.currentAnimeId = 1;
    this.currentEpisodeId = 1;
    this.currentReviewId = 1;
    this.currentCommentId = 1;
    
    // Initialize session store
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // 24 hours
    });
    
    // Initialize with some admin user
    this.seedInitialData();
  }

  private async seedInitialData() {
    // Create admin user
    const hashedPassword = await bcrypt.hash("admin123", 10);
    this.createUser({
      email: "admin@example.com",
      password: hashedPassword,
      username: "admin",
      role: "admin",
      avatar_url: "",
    });
    
    // Create custom admin user
    const customAdminPassword = await bcrypt.hash("ommishra123", 10);
    this.createUser({
      email: "ommishra782725@gmail.com",
      password: customAdminPassword,
      username: "ommishra",
      role: "admin",
      avatar_url: "",
    });

    // Create regular user
    const userHashedPassword = await bcrypt.hash("user123", 10);
    this.createUser({
      email: "user@example.com",
      password: userHashedPassword,
      username: "user",
      role: "user",
      avatar_url: "",
    });
    
    // Seed anime data
    this.createAnime({
      title: "Attack on Titan",
      alternative_title: "Shingeki no Kyojin",
      synopsis: "Humanity's last remnants live behind walls to protect themselves from giant humanoid Titans that devour humans.",
      release_year: 2013,
      status: "completed",
      type: "TV",
      genres: ["Action", "Drama", "Fantasy"],
      rating: "8.9",
      episodes_count: 75,
      cover_image: "https://m.media-amazon.com/images/M/MV5BNDFjYTIxMjctYTQ2ZC00OGQ4LWE3OGYtNDdiMzNiNDZlMDAwXkEyXkFqcGdeQXVyNzI3NjY3NjQ@._V1_FMjpg_UX1000_.jpg",
      banner_image: "https://m.media-amazon.com/images/M/MV5BNDFjYTIxMjctYTQ2ZC00OGQ4LWE3OGYtNDdiMzNiNDZlMDAwXkEyXkFqcGdeQXVyNzI3NjY3NjQ@._V1_.jpg",
      featured: true,
      trending: true,
      top_rated: true
    });
    
    this.createAnime({
      title: "Demon Slayer",
      alternative_title: "Kimetsu no Yaiba",
      synopsis: "A young man named Tanjiro joins the Demon Slayer Corps to avenge his family and cure his sister.",
      release_year: 2019,
      status: "ongoing",
      type: "TV",
      genres: ["Action", "Fantasy", "Adventure"],
      rating: "8.7",
      episodes_count: 44,
      cover_image: "https://m.media-amazon.com/images/M/MV5BZjZjNzI5MDctY2Y4YS00NmM4LTljMmItZTFkOTExNGI3ODRhXkEyXkFqcGdeQXVyNjc3MjQzNTI@._V1_.jpg",
      banner_image: "https://m.media-amazon.com/images/M/MV5BZjZjNzI5MDctY2Y4YS00NmM4LTljMmItZTFkOTExNGI3ODRhXkEyXkFqcGdeQXVyNjc3MjQzNTI@._V1_.jpg",
      featured: true,
      trending: true,
      top_rated: true
    });
    
    this.createAnime({
      title: "My Hero Academia",
      alternative_title: "Boku no Hero Academia",
      synopsis: "In a world where most people have superpowers, a boy born without them aims to become the greatest hero.",
      release_year: 2016,
      status: "ongoing",
      type: "TV",
      genres: ["Action", "Comedy", "Superhero"],
      rating: "8.4",
      episodes_count: 113,
      cover_image: "https://m.media-amazon.com/images/M/MV5BOGZmYjdjN2UtNDAwZi00YmEyLWFhNTEtNjM1OTc5ODg0MGEyXkEyXkFqcGdeQXVyMTA1NjE5MTAz._V1_.jpg",
      banner_image: "https://m.media-amazon.com/images/M/MV5BOGZmYjdjN2UtNDAwZi00YmEyLWFhNTEtNjM1OTc5ODg0MGEyXkEyXkFqcGdeQXVyMTA1NjE5MTAz._V1_.jpg",
      featured: false,
      trending: true,
      top_rated: false
    });
    
    // Add episodes for Attack on Titan
    this.createEpisode({
      title: "To You, 2000 Years From Now",
      anime_id: 1,
      episode_number: 1,
      season_number: 1,
      duration: "24:00",
      thumbnail: "https://m.media-amazon.com/images/M/MV5BNDFjYTIxMjctYTQ2ZC00OGQ4LWE3OGYtNDdiMzNiNDZlMDAwXkEyXkFqcGdeQXVyNzI3NjY3NjQ@._V1_.jpg",
      video_480p: "https://example.com/aot-s1e1-480p.mp4",
      video_720p: "https://example.com/aot-s1e1-720p.mp4",
      video_1080p: "https://example.com/aot-s1e1-1080p.mp4",
      video_embed: "https://www.youtube.com/embed/LHtdKWJdif4",
      description: "After 100 years of peace, the Colossal Titan breaches the wall and Titans enter the city.",
    });
    
    this.createEpisode({
      title: "That Day",
      anime_id: 1,
      episode_number: 2,
      season_number: 1,
      duration: "24:00",
      thumbnail: "https://m.media-amazon.com/images/M/MV5BNDFjYTIxMjctYTQ2ZC00OGQ4LWE3OGYtNDdiMzNiNDZlMDAwXkEyXkFqcGdeQXVyNzI3NjY3NjQ@._V1_.jpg",
      video_480p: "https://example.com/aot-s1e2-480p.mp4",
      video_720p: "https://example.com/aot-s1e2-720p.mp4",
      video_1080p: "https://example.com/aot-s1e2-1080p.mp4",
      video_embed: "https://www.youtube.com/embed/LHtdKWJdif4",
      description: "Eren joins the military to fight Titans and avenge his mother.",
    });
    
    // Add episodes for Demon Slayer
    this.createEpisode({
      title: "Cruelty",
      anime_id: 2,
      episode_number: 1,
      season_number: 1,
      duration: "23:00",
      thumbnail: "https://m.media-amazon.com/images/M/MV5BZjZjNzI5MDctY2Y4YS00NmM4LTljMmItZTFkOTExNGI3ODRhXkEyXkFqcGdeQXVyNjc3MjQzNTI@._V1_.jpg",
      video_480p: "https://example.com/ds-s1e1-480p.mp4",
      video_720p: "https://example.com/ds-s1e1-720p.mp4",
      video_1080p: "https://example.com/ds-s1e1-1080p.mp4",
      video_embed: "https://www.youtube.com/embed/VQGCKyvzIM4",
      description: "Tanjiro returns to find his family slaughtered by demons and his sister transformed.",
    });
    
    // Add episodes for My Hero Academia
    this.createEpisode({
      title: "Izuku Midoriya: Origin",
      anime_id: 3,
      episode_number: 1,
      season_number: 1,
      duration: "24:00",
      thumbnail: "https://m.media-amazon.com/images/M/MV5BOGZmYjdjN2UtNDAwZi00YmEyLWFhNTEtNjM1OTc5ODg0MGEyXkEyXkFqcGdeQXVyMTA1NjE5MTAz._V1_.jpg",
      video_480p: "https://example.com/mha-s1e1-480p.mp4",
      video_720p: "https://example.com/mha-s1e1-720p.mp4",
      video_1080p: "https://example.com/mha-s1e1-1080p.mp4",
      video_embed: "https://www.youtube.com/embed/D5fYOnwYkj4",
      description: "Izuku Midoriya dreams of becoming a hero despite being born without a Quirk.",
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.usersMap.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    for (const user of this.usersMap.values()) {
      if (user.email === email) {
        return user;
      }
    }
    return undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    for (const user of this.usersMap.values()) {
      if (user.username === username) {
        return user;
      }
    }
    return undefined;
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.usersMap.values());
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const now = new Date();
    const user: User = { ...insertUser, id, created_at: now };
    this.usersMap.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.usersMap.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.usersMap.set(id, updatedUser);
    return updatedUser;
  }

  async deleteUser(id: number): Promise<boolean> {
    return this.usersMap.delete(id);
  }

  // Anime operations
  async getAnime(id: number): Promise<Anime | undefined> {
    return this.animesMap.get(id);
  }

  async getAllAnimes(): Promise<Anime[]> {
    return Array.from(this.animesMap.values());
  }

  async getFeaturedAnimes(limit: number = 5): Promise<Anime[]> {
    return Array.from(this.animesMap.values())
      .filter(anime => anime.featured)
      .slice(0, limit);
  }

  async getTrendingAnimes(limit: number = 10): Promise<Anime[]> {
    return Array.from(this.animesMap.values())
      .filter(anime => anime.trending)
      .slice(0, limit);
  }

  async getRecentAnimes(limit: number = 10): Promise<Anime[]> {
    return Array.from(this.animesMap.values())
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
      .slice(0, limit);
  }

  async getTopRatedAnimes(limit: number = 10): Promise<Anime[]> {
    return Array.from(this.animesMap.values())
      .filter(anime => anime.top_rated)
      .slice(0, limit);
  }

  async createAnime(insertAnime: InsertAnime): Promise<Anime> {
    const id = this.currentAnimeId++;
    const now = new Date();
    const anime: Anime = { ...insertAnime, id, created_at: now };
    this.animesMap.set(id, anime);
    return anime;
  }

  async updateAnime(id: number, animeData: InsertAnime): Promise<Anime | undefined> {
    const anime = this.animesMap.get(id);
    if (!anime) return undefined;
    
    const updatedAnime = { ...anime, ...animeData };
    this.animesMap.set(id, updatedAnime);
    return updatedAnime;
  }

  async deleteAnime(id: number): Promise<boolean> {
    // Delete all related episodes
    for (const [episodeId, episode] of this.episodesMap.entries()) {
      if (episode.anime_id === id) {
        this.episodesMap.delete(episodeId);
      }
    }
    
    // Delete all related reviews
    for (const [reviewId, review] of this.reviewsMap.entries()) {
      if (review.anime_id === id) {
        this.reviewsMap.delete(reviewId);
      }
    }
    
    return this.animesMap.delete(id);
  }

  // Episode operations
  async getEpisode(id: number): Promise<Episode | undefined> {
    return this.episodesMap.get(id);
  }

  async getAllEpisodes(): Promise<Episode[]> {
    return Array.from(this.episodesMap.values());
  }

  async getEpisodesByAnime(animeId: number): Promise<Episode[]> {
    return Array.from(this.episodesMap.values())
      .filter(episode => episode.anime_id === animeId);
  }

  async getRecentEpisodes(limit: number = 10): Promise<Episode[]> {
    return Array.from(this.episodesMap.values())
      .sort((a, b) => new Date(b.release_date).getTime() - new Date(a.release_date).getTime())
      .slice(0, limit);
  }

  async createEpisode(insertEpisode: InsertEpisode): Promise<Episode> {
    const id = this.currentEpisodeId++;
    const now = new Date();
    const episode: Episode = { ...insertEpisode, id, release_date: now };
    this.episodesMap.set(id, episode);
    return episode;
  }

  async updateEpisode(id: number, episodeData: InsertEpisode): Promise<Episode | undefined> {
    const episode = this.episodesMap.get(id);
    if (!episode) return undefined;
    
    const updatedEpisode = { ...episode, ...episodeData };
    this.episodesMap.set(id, updatedEpisode);
    return updatedEpisode;
  }

  async deleteEpisode(id: number): Promise<boolean> {
    // Delete all comments related to this episode
    for (const [commentId, comment] of this.commentsMap.entries()) {
      if (comment.episode_id === id) {
        this.commentsMap.delete(commentId);
      }
    }
    
    return this.episodesMap.delete(id);
  }

  // Review operations
  async getReview(id: number): Promise<Review | undefined> {
    return this.reviewsMap.get(id);
  }

  async getReviewsByAnime(animeId: number): Promise<(Review & { user: User })[]> {
    const reviews = Array.from(this.reviewsMap.values())
      .filter(review => review.anime_id === animeId)
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    
    // Join with user data
    return reviews.map(review => {
      const user = this.usersMap.get(review.user_id);
      if (!user) {
        // This should not happen in a real system, but handle it gracefully
        const fallbackUser: User = {
          id: 0,
          email: "deleted@user.com",
          password: "",
          username: "Deleted User",
          role: "user",
          created_at: new Date()
        };
        return { ...review, user: fallbackUser };
      }
      // Exclude password from user object
      const { password, ...userWithoutPassword } = user;
      return { ...review, user: userWithoutPassword as User };
    });
  }

  async createReview(insertReview: InsertReview): Promise<Review> {
    const id = this.currentReviewId++;
    const now = new Date();
    const review: Review = { ...insertReview, id, created_at: now };
    this.reviewsMap.set(id, review);
    return review;
  }

  async deleteReview(id: number): Promise<boolean> {
    return this.reviewsMap.delete(id);
  }

  // Comment operations
  async getComment(id: number): Promise<Comment | undefined> {
    return this.commentsMap.get(id);
  }

  async getCommentsByEpisode(episodeId: number): Promise<(Comment & { user: User; replies?: (Comment & { user: User })[] })[]> {
    // Get all comments for this episode
    const allComments = Array.from(this.commentsMap.values())
      .filter(comment => comment.episode_id === episodeId);
    
    // Separate top-level comments from replies
    const topLevelComments = allComments.filter(comment => !comment.parent_id);
    const replies = allComments.filter(comment => comment.parent_id);
    
    // Join with user data and organize replies
    return topLevelComments
      .map(comment => {
        const user = this.usersMap.get(comment.user_id);
        if (!user) {
          const fallbackUser: User = {
            id: 0,
            email: "deleted@user.com",
            password: "",
            username: "Deleted User",
            role: "user",
            created_at: new Date()
          };
          return { ...comment, user: fallbackUser };
        }
        
        // Exclude password from user object
        const { password, ...userWithoutPassword } = user;
        
        // Get replies for this comment
        const commentReplies = replies
          .filter(reply => reply.parent_id === comment.id)
          .map(reply => {
            const replyUser = this.usersMap.get(reply.user_id);
            if (!replyUser) {
              const fallbackUser: User = {
                id: 0,
                email: "deleted@user.com",
                password: "",
                username: "Deleted User",
                role: "user",
                created_at: new Date()
              };
              return { ...reply, user: fallbackUser };
            }
            
            // Exclude password from user object
            const { password, ...replyUserWithoutPassword } = replyUser;
            return { ...reply, user: replyUserWithoutPassword as User };
          })
          .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
        
        return { 
          ...comment, 
          user: userWithoutPassword as User,
          replies: commentReplies.length > 0 ? commentReplies : undefined
        };
      })
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  }

  async createComment(insertComment: InsertComment): Promise<Comment> {
    const id = this.currentCommentId++;
    const now = new Date();
    const comment: Comment = { 
      ...insertComment, 
      id, 
      created_at: now,
      likes: 0,
      dislikes: 0 
    };
    this.commentsMap.set(id, comment);
    return comment;
  }

  async voteComment(id: number, isLike: boolean): Promise<Comment | undefined> {
    const comment = this.commentsMap.get(id);
    if (!comment) return undefined;
    
    const updatedComment = { 
      ...comment,
      likes: isLike ? comment.likes + 1 : comment.likes,
      dislikes: !isLike ? comment.dislikes + 1 : comment.dislikes
    };
    
    this.commentsMap.set(id, updatedComment);
    return updatedComment;
  }

  async deleteComment(id: number): Promise<boolean> {
    // Delete all replies to this comment
    for (const [commentId, comment] of this.commentsMap.entries()) {
      if (comment.parent_id === id) {
        this.commentsMap.delete(commentId);
      }
    }
    
    return this.commentsMap.delete(id);
  }
}

// Export a singleton instance
export const storage = new MemStorage();
