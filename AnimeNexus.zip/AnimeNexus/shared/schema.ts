import { pgTable, text, serial, integer, boolean, timestamp, uuid, json, foreignKey } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  username: text("username").notNull(),
  role: text("role").default("user").notNull(),
  avatar_url: text("avatar_url"),
  created_at: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  email: true,
  password: true,
  username: true,
  role: true,
  avatar_url: true,
});

// Anime
export const animes = pgTable("animes", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  alternative_title: text("alternative_title"),
  synopsis: text("synopsis").notNull(),
  type: text("type").notNull(), // TV, Movie, OVA, etc.
  status: text("status").notNull(), // Airing, Completed, Upcoming
  release_year: integer("release_year").notNull(),
  rating: text("rating"),
  genres: text("genres").array().notNull(),
  studios: text("studios"),
  director: text("director"),
  cover_image: text("cover_image").notNull(),
  banner_image: text("banner_image").notNull(),
  created_at: timestamp("created_at").defaultNow().notNull(),
  featured: boolean("featured").default(false),
  trending: boolean("trending").default(false),
  top_rated: boolean("top_rated").default(false),
  episodes_count: integer("episodes_count").default(0),
  tmdb_id: integer("tmdb_id"),
  voice_actors: text("voice_actors").array(),
});

export const insertAnimeSchema = createInsertSchema(animes).pick({
  title: true,
  alternative_title: true,
  synopsis: true,
  type: true,
  status: true,
  release_year: true,
  rating: true,
  genres: true,
  studios: true,
  director: true,
  cover_image: true,
  banner_image: true,
  featured: true,
  trending: true,
  top_rated: true,
  episodes_count: true,
  tmdb_id: true,
  voice_actors: true,
});

// Episodes
export const episodes = pgTable("episodes", {
  id: serial("id").primaryKey(),
  anime_id: integer("anime_id").notNull().references(() => animes.id, { onDelete: 'cascade' }),
  title: text("title").notNull(),
  episode_number: integer("episode_number").notNull(),
  season_number: integer("season_number").default(1).notNull(),
  duration: text("duration").notNull(),
  thumbnail: text("thumbnail").notNull(),
  video_1080p: text("video_1080p"),
  video_720p: text("video_720p"),
  video_480p: text("video_480p"),
  video_embed: text("video_embed"),
  release_date: timestamp("release_date").defaultNow().notNull(),
  description: text("description"),
});

export const insertEpisodeSchema = createInsertSchema(episodes).pick({
  anime_id: true,
  title: true,
  episode_number: true,
  season_number: true,
  duration: true,
  thumbnail: true,
  video_1080p: true,
  video_720p: true,
  video_480p: true,
  video_embed: true,
  description: true,
});

// Reviews
export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  anime_id: integer("anime_id").notNull().references(() => animes.id, { onDelete: 'cascade' }),
  title: text("title").notNull(),
  content: text("content").notNull(),
  rating: integer("rating").notNull(), // 1-5
  created_at: timestamp("created_at").defaultNow().notNull(),
});

export const insertReviewSchema = createInsertSchema(reviews).pick({
  user_id: true,
  anime_id: true,
  title: true,
  content: true,
  rating: true,
});

// Comments
export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  episode_id: integer("episode_id").notNull().references(() => episodes.id, { onDelete: 'cascade' }),
  content: text("content").notNull(),
  created_at: timestamp("created_at").defaultNow().notNull(),
  parent_id: integer("parent_id").references(() => comments.id, { onDelete: 'cascade' }),
  likes: integer("likes").default(0),
  dislikes: integer("dislikes").default(0),
});

export const insertCommentSchema = createInsertSchema(comments).pick({
  user_id: true,
  episode_id: true,
  content: true,
  parent_id: true,
});

// Export types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Anime = typeof animes.$inferSelect;
export type InsertAnime = z.infer<typeof insertAnimeSchema>;

export type Episode = typeof episodes.$inferSelect;
export type InsertEpisode = z.infer<typeof insertEpisodeSchema>;

export type Review = typeof reviews.$inferSelect;
export type InsertReview = z.infer<typeof insertReviewSchema>;

export type Comment = typeof comments.$inferSelect;
export type InsertComment = z.infer<typeof insertCommentSchema>;
